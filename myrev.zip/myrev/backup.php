<?php
  session_start(); ?>


<?php
 


		$connect = mysqli_connect("localhost","root","root","tugasakhir");
   
   if (!$connect) {
    die("Connection Failed:" .mysqli_connect_error());

   }
  
   $uname = $_SESSION['username'];
   $tahunajar = $_POST['tahunajar'];
   $semester = $_POST['semester'];
  
 $sql = "SELECT * FROM tb_data_siswa WHERE username='".$uname."' AND semester='".$semester."' AND tahunajar='".$tahunajar."' ORDER BY id ASC ";  
 $result = mysqli_query($connect, $sql);  

  if(mysqli_num_rows($result) > 0)  
 {  
 
      while($row = mysqli_fetch_array($result))  
      { 
            

        $id[] = $row["id"];
        $nama[] = $row["nama"];
        $c1[] = $row["c1"];
        $c2[] = $row["c2"];
        $c3[] = $row["c3"];
        $c4[] = $row["c4"];
        $c5[] = $row["c5"];
        $c6[] = $row["c6"];
        $c7[] = $row["c7"];
        $c8[] = $row["c8"];
        $c9[] = $row["c9"];
        $c10[] = $row["c10"];
        $c11[] = $row["c11"];
        $c12[] = $row["c12"];
        $c13[] = $row["c13"];
        $c14[] = $row["c14"];



      }

       $record = count($nama);

       if ($record <= 30) {
         # code...
       }

       ?>



 <link href="/myrev/template/sb-admin/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.11/css/dataTables.bootstrap.min.css">
<script src="https://cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.11/js/dataTables.bootstrap.min.js"></script>
  
  
    <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse"  href="#collapse1"><h2>Data Siswa<?php echo $record ;?></h2></a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse">
        <div class="panel-body">
              <div class="col-lg-12">
                        
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Nama</th>
                                        <th>c1</th>
                                        <th>c2</th>
                                        <th>c3</th>
                                        <th>c4</th>
                                        <th>c5</th>
                                        <th>c6</th>
                                        <th>c7</th>
                                        <th>c8</th>
                                        <th>c9</th>
                                        <th>c10</th>
                                        <th>c11</th>
                                        <th>c12</th>
                                        <th>c13</th>
                                        <th>c14</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                         <td><?php 
              
                                          $arrlength = count($id);
                                          for ($i=0; $i < $arrlength; $i++) { 
                                            echo $id[$i]."<br/>";
                                          } ?> </td>
                                        <td><?php 
              
                                          $arrlength = count($nama);
                                          for ($i=0; $i < $arrlength; $i++) { 
                                            echo $nama[$i]."<br/>";
                                          } ?> </td>
                                        <td><?php 
                                    
                                    $arrlength = count($c1);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c1[$i]."<br/>";
                                    } ?> </td>
                                    
                                <td><?php   
                                    $arrlength = count($c2);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c2[$i]."<br/>";
                                    } ?></td>

                                <td><?php   
                                    $arrlength = count($c3);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c3[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c4);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c4[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c5);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c5[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c6);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c6[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c7);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c7[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c8);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c8[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c9);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c9[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c10);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c10[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c11);
                                    for ($i=0; $i < $arrlength; $i++) { 

                                      echo $c11[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c12);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c12[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c13);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c13[$i]."<br/>";
                                    }?></td>

                                <td><?php   
                                    $arrlength = count($c14);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c14[$i]."<br/>";
                                    } ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

        </div>
      </div>
    </div>

    <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse2"><h2>Dataset</h2></a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <div class="panel-body">
              <div class="col-lg-12">
                        
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Nama</th>
                                        <th>c1</th>
                                        <th>c2</th>
                                        <th>c3</th>
                                        <th>c4</th>
                                        <th>c5</th>
                                        <th>c6</th>
                                        <th>c7</th>
                                        <th>c8</th>
                                        <th>c9</th>
                                        <th>c10</th>
                                        <th>c11</th>
                                        <th>c12</th>
                                        <th>c13</th>
                                        <th>c14</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                         <td><?php 
              
                                          $arrlength = count($id);
                                          for ($i=0; $i < $arrlength; $i++) { 
                                            echo $id[$i]."<br/>";
                                          } ?> </td>
                                        <td><?php 
              
                                          $arrlength = count($nama);
                                          for ($i=0; $i < $arrlength; $i++) { 
                                            echo $nama[$i]."<br/>";
                                          } ?> </td>
                                        <td><?php 
                                    
                                    $arrlength = count($c1);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c1[$i]."<br/>";
                                    } ?> </td>
                                    
                                <td><?php   
                                    $arrlength = count($c2);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c2[$i]."<br/>";
                                    } ?></td>

                                <td><?php   
                                    $arrlength = count($c3);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c3[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c4);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c4[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c5);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c5[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c6);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c6[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c7);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c7[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c8);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c8[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c9);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c9[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c10);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo $c10[$i]."<br/>";
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c11);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                    echo ubah_c11($c11[$i])."<br/>";
                                    $uc11 []= ubah_c11($c11[$i]);

                                    }?></td>
                                <td><?php   
                                
                                    $arrlength = count($c12);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo ubah_c12($c12[$i])."<br/>";
                                      $uc12 []= ubah_c12($c12[$i]);
                                    }?></td>
                                <td><?php   
                                    $arrlength = count($c13);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo ubah_c13($c13[$i])."<br/>";
                                      $uc13 []= ubah_c13($c13[$i]);
                                    }?></td>

                                <td><?php   
                                    $arrlength = count($c14);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo ubah_c14($c14[$i])."<br/>";
                                      $uc14 []= ubah_c14($c14[$i]);
                                    } ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

        </div>
      </div>
    </div>

    <?php 


    $connect = mysqli_connect("localhost","root","root","tugasakhir");
   
         if (!$connect) {
          die("Connection Failed:" .mysqli_connect_error());

         }
        
        
       $sql = "SELECT * FROM tb_bobot ORDER BY id ASC ";  
       $result = mysqli_query($connect, $sql);  

        if(mysqli_num_rows($result) > 0)  
       {  
            while($row = mysqli_fetch_array($result))  
            {

              $bobot[] = $row["nilai"];
              $atribut[] = $row["atribut"];
              $mapel[] = $row["mapel"];
            }

        }
       ?>

    <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse3"><h2>Bobot Kriteria Penilaian</h2></a>
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <div class="panel-body">
              <div class="col-lg-12">
                        
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr><th>Matapelajaran</th>
                                     <th>Atribut</th>
                                     <th>Nilai</th>
                                     </tr>
                               
                                        
                                   
                                </thead>
                                <tbody>
                                  <tr></tr
                                   
                                     <?php   
                                    $arrlength = count($bobot);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                      echo "<tr><td>".$mapel[$i]."</td><td>".$atribut[$i]."</td><td>".$bobot[$i]."</td></tr>";
                                    } ?>
                                         
                                  
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

        </div>
      </div>
    </div>

    


    <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse4"><h2>Tabel Faktor Ternormalisasi</h2></a>
        </h4>
      </div>
      <div id="collapse4" class="panel-collapse collapse">
        <div class="panel-body">
              <div class="col-lg-12">
                        
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                             
                              <thead>
                                        <th>Nama</th>
                                        <th>c1</th>
                                        <th>c2</th>
                                        <th>c3</th>
                                        <th>c4</th>
                                        <th>c5</th>
                                        <th>c6</th>
                                        <th>c7</th>
                                        <th>c8</th>
                                        <th>c9</th>
                                        <th>c10</th>
                                        <th>c11</th>
                                        <th>c12</th>
                                        <th>c13</th>
                                        <th>c14</th>
                              </thead>

                              <tr><td>
                                 <?php
                                  $arrlength = count($nama);
                                  for ($i=0; $i < $arrlength; $i++) { 
                                    
                                    echo $nama[$i]."<br/>";
                                  }?></td>
                              <td>
                                 <?php
                                  $max = max($c1);
                                  for ($i=0; $i < $arrlength; $i++) { 
                                    $mkc1[] =($c1[$i] / $max);
                                    echo number_format($mkc1[$i],2)."<br/>";
                                  }?></td> 
                              <td><?php $max = max($c2);
                                  
                                  for ($i=0; $i < $arrlength; $i++) { 
                                    $mkc2[] =($c2[$i] / $max);
                                    echo number_format($mkc2[$i],2)."<br/>";
                                  }?></td>
                              <td><?php $max = max($c3);
                                
                                  for ($i=0; $i < $arrlength; $i++) { 
                                    $mkc3[] =($c3[$i] / $max);
                                    echo number_format($mkc3[$i],2)."<br/>";
                                  }?></td>
                              <td><?php $max = max($c4);
                                
                                  for ($i=0; $i < $arrlength; $i++) { 
                                    $mkc4[] =($c4[$i]/$max);
                                    echo number_format($mkc4[$i],2)."<br/>";
                                  }?></td>
                              <td><?php $max = max($c5);
                                  
                                  for ($i=0; $i < $arrlength; $i++) { 
                                    $mkc5[] =(  $c5[$i] / $max );
                                    echo number_format($mkc5[$i],2)."<br/>";
                                  } ?></td>
                              <td><?php $max = max($c6);
                                  
                                  for ($i=0; $i < $arrlength; $i++) { 
                                    $mkc6[] =( $c6[$i] / $max);
                                    echo number_format($mkc6[$i],2)."<br/>";
                                  } ?></td>
                              <td><?php $max = max($c7);
                                  
                                  for ($i=0; $i < $arrlength; $i++) { 
                                    $mkc7[] =(  $c7[$i] / $max );
                                    echo number_format($mkc7[$i],2)."<br/>";
                                  } ?></td>
                              <td><?php $max = max($c8);
                                  
                                  for ($i=0; $i < $arrlength; $i++) { 
                                    $mkc8[] =( $c8[$i] / $max );
                                    echo number_format($mkc8[$i],2)."<br/>";
                                  } ?></td>
                              <td><?php $max = max($c9);
                                  
                                  for ($i=0; $i < $arrlength; $i++) { 
                                    $mkc9[] =(  $c9[$i] / $max );
                                    echo number_format($mkc9[$i],2)."<br/>";
                                  } ?></td>
                              <td><?php $max = max($c10);
                                  
                                  for ($i=0; $i < $arrlength; $i++) { 
                                    $mkc10[] =(  $c10[$i] / $max  );
                                    echo number_format($mkc10[$i],2)."<br/>";
                                  } ?></td>
                              <td><?php $max = max($uc11);
                                  
                                  for ($i=0; $i < $arrlength; $i++) { 
                                    $mkc11[] =( $uc11[$i] / $max );
                                    echo number_format($mkc11[$i],2)."<br/>";
                                  } ?></td>
                              <td><?php $max = max($uc12);
                                  
                                  for ($i=0; $i < $arrlength; $i++) { 
                                    $mkc12[] =( $uc12[$i] / $max );
                                    echo number_format($mkc12[$i],2)."<br/>";
                                  } ?></td>
                              <td><?php $max = max($uc13);
                                  
                                  for ($i=0; $i < $arrlength; $i++) { 
                                    $mkc13[] =( $uc13[$i] / $max );
                                    echo number_format($mkc13[$i],2)."<br/>";
                                  } ?></td>
                              <td><?php $max = max($uc14);
                                  
                                  for ($i=0; $i < $arrlength; $i++) { 
                                    $mkc14[] =( $uc14[$i] / $max  );
                                    echo number_format($mkc14[$i],2)."<br/>";
                                  } ?></td>
                        
                                  </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

        </div>
      </div>
    </div>

<?php
  for ($i=0; $i < $arrlength; $i++) { 
  $mkbc1[]= number_format($mkc1[$i]*$bobot[0],2);
  $mkbc2[] =number_format($mkc2[$i]*$bobot[1],2);
  $mkbc3[]= number_format($mkc3[$i]*$bobot[2],2);
  $mkbc4[] =number_format($mkc4[$i]*$bobot[3],2);
  $mkbc5[]= number_format($mkc5[$i]*$bobot[4],2);
  $mkbc6[] =number_format($mkc6[$i]*$bobot[5],2);
  $mkbc7[]= number_format($mkc7[$i]*$bobot[6],2);
  $mkbc8[] =number_format($mkc8[$i]*$bobot[7],2);
  $mkbc9[]= number_format($mkc9[$i]*$bobot[8],2);
  $mkbc10[] =number_format($mkc10[$i]*$bobot[9],2);
  $mkbc11[]= number_format($mkc11[$i]*$bobot[10],2);
  $mkbc12[] =number_format($mkc12[$i]*$bobot[11],2);
  $mkbc13[]= number_format($mkc13[$i]*$bobot[12],2);
  $mkbc14[] =number_format($mkc14[$i]*$bobot[13],2);
  $mkbchasil[] = $mkbc1[$i] + $mkbc2[$i] + $mkbc3[$i] + $mkbc4[$i] +
                 $mkbc5[$i] + $mkbc6[$i] + $mkbc7[$i] + $mkbc8[$i] +              
                 $mkbc9[$i] + $mkbc10[$i] + $mkbc11[$i] + $mkbc12[$i] 
                 + $mkbc13[$i] + $mkbc14[$i] ;    
  }


   
?>

    
<div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse5"><h2>Tabel Hasil Akhir</h2></a>
        </h4>
      </div>
      <div id="collapse5" class="panel-collapse collapse">
        <div class="panel-body">
              <div class="col-lg-12">
                        
                        <div class="table-responsive">
                            <table id="hasil" class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Hasil Akhir</th> 
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php   
                                    $b = 0;
                                    $arrlength = count($nama);
                                    for ($i=0; $i < $arrlength; $i++) { 
                                    $b = $b+1;

                                      echo "<tr><td>".$b."</td><td>".$nama[$i]."</td><td>".$mkbchasil[$i]."</td></tr>";
                                    }?>
                                   
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

        </div>
      </div>
    </div>

<?php } else { 
      echo "<div class='col-lg-12'>";
      echo "Data tidak ditemukan";
      echo "<br/>".$uname;
      echo "<br/>".$tahunajar;
      echo "<br/>".$semester;
      echo "</div>";
		
  } 
?>

<?php
function ubah_c11($nilai){

    if ($nilai == "A") {
      $hasil = "85";
    }
     if ($nilai == "B+") {
      $hasil = "75";
    }
     if ($nilai == "B") {
      $hasil = "70";
    }
     if ($nilai == "B-") {
      $hasil = "65";
    }
     if ($nilai == "C+") {
      $hasil = "60";
    }
     if ($nilai == "C") {
      $hasil = "55";
    }
     if ($nilai == "D") {
      $hasil = "50";
    }
    return $hasil ;
}
function ubah_c12($nilai){

    if ($nilai == "A") {
      $hasil = "89";
    }
     if ($nilai == "B+") {
      $hasil = "85";
    }
     if ($nilai == "B") {
      $hasil = "80";
    }
     if ($nilai == "B-") {
      $hasil = "75";
    }
     if ($nilai == "C+") {
      $hasil = "70";
    }
     if ($nilai == "C-") {
      $hasil = "65";
    }
     if ($nilai == "D") {
      $hasil = "60";
    }
    return $hasil ;
}
function ubah_c13($nilai){

    if ($nilai == "A") {
      $hasil = "87";
    }
     if ($nilai == "B+") {
      $hasil = "82";
    }
     if ($nilai == "B") {
      $hasil = "77";
    }
     if ($nilai == "B-") {
      $hasil = "72";
    }
     if ($nilai == "C+") {
      $hasil = "67";
    }
     if ($nilai == "C-") {
      $hasil = "62";
    }
     if ($nilai == "D") {
      $hasil = "57";
    }
    return $hasil ;
}
function ubah_c14($nilai){

    if ($nilai >= 0 && $nilai <= 2) {
      $hasil = "80";
    }
     if ($nilai >= 3 && $nilai <=5) {
      $hasil = "72";
    }
     if ($nilai == 6 && $nilai <=7) {
      $hasil = "66";
    }
     if ($nilai >= 8 && $nilai >=10) {
      $hasil = "60";
    }
    return $hasil ;
}

  
?>
<script type="text/javascript">
  $(document).ready(function() {
  
    $('#hasil').DataTable();

});
</script>
        
    

