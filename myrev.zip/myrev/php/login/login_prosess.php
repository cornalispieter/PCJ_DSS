<?php
session_start();

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "tugasakhir";
	$conn = mysqli_connect($servername,$username,$password,$dbname);

	 if (!$conn) {
	 	die("Connection Failed:" .mysqli_connect_error());
	 }

	$uname = $_POST["uname"];
	$passw =md5($_POST["passw"]);

	$sql = "SELECT username,job_desk FROM user WHERE username='$uname' AND password='$passw'";
	$result = mysqli_query($conn,$sql);
	$num_row = mysqli_num_rows($result);
	if ($num_row > 0) {
		$data = mysqli_fetch_array($result);
		$_SESSION['username'] = $data["username"];
		$_SESSION['job_desk'] = $data["job_desk"];
 		echo json_encode($data);

	}

?>
