<?php
  session_start(); ?>


<?php



		$connect = mysqli_connect("localhost","root","","tugasakhir");

   if (!$connect) {
    die("Connection Failed:" .mysqli_connect_error());

   }

   $uname = $_SESSION['username'];
   $tahunajar = $_POST['tahunajar'];
   $semester = $_POST['semester'];
      $kelas = $_POST['kelas'];

 $sql = "SELECT * FROM tb_data_siswa WHERE username='".$uname."' AND semester='".$semester."' AND tahunajar='".$tahunajar."' AND kelas='".$kelas."'  ORDER BY id ASC ";
 $result = mysqli_query($connect, $sql);

  if(mysqli_num_rows($result) > 0)
 {

      while($row = mysqli_fetch_array($result))
      {


        $id[] = $row["id"];
        $nama[] = $row["nama"];
         $nis[] = $row["nis"];
        $c1[] = $row["c1"];
        $c2[] = $row["c2"];
        $c3[] = $row["c3"];
        $c4[] = $row["c4"];
        $c5[] = $row["c5"];
        $c6[] = $row["c6"];
        $c7[] = $row["c7"];
        $c8[] = $row["c8"];
        $c9[] = $row["c9"];
        $c10[] = $row["c10"];
        $c11[] = $row["c11"];
        $c12[] = $row["c12"];
        $c13[] = $row["c13"];
        $c14[] = $row["c14"];



      }

       $record = count($nama);

       if ($record >= 30) { ?>


    <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse"  href="#collapse1"><h2>Data Siswa</h2></a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse">
        <div class="panel-body">
              <div class="col-lg-12">

                        <div class="table-responsive">
                            <table class="table table-bordered ">
                                <thead>
                                    <tr>
                                        <th>Nis</th>
                                        <th>Nama</th>
                                        <th>Nilai Akademis</th>
                                        <th>Nilai Pramuka</th>
                                        <th>Nilai Kedisiplinan</th>
                                        <th>Nilai Kebersihan</th>
                                        <th>Nilai Absensi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                    <td><?php
                                    $arrlength = count($c11);
                                    for ($i=0; $i < $arrlength; $i++) {

                                      echo $nis[$i]."<br/>";
                                    }?></td>
                                    <td><?php
                                    $arrlength = count($c11);
                                    for ($i=0; $i < $arrlength; $i++) {

                                      echo $nama[$i]."<br/>";
                                    }?></td>
                                    <td><?php
                                    $arrlength = count($c11);
                                    for ($i=0; $i < $arrlength; $i++) {
                                      $naka[] = ($c1[$i]+$c2[$i]+$c3[$i]+$c4[$i]+$c5[$i]+$c6[$i]+$c7[$i]+$c8[$i]+$c9[$i]+$c10[$i])/10;
                                      $nakau[] = ubah_naka($naka[$i]);
                                      echo $naka[$i]."<br/>";
                                    }?></td>

                                <td><?php
                                    $arrlength = count($c11);
                                    for ($i=0; $i < $arrlength; $i++) {

                                      echo $c11[$i]."<br/>";
                                    }?></td>
                                <td><?php
                                    $arrlength = count($c12);
                                    for ($i=0; $i < $arrlength; $i++) {
                                      echo $c12[$i]."<br/>";
                                    }?></td>
                                <td><?php
                                    $arrlength = count($c13);
                                    for ($i=0; $i < $arrlength; $i++) {
                                      echo $c13[$i]."<br/>";
                                    }?></td>

                                <td><?php
                                    $arrlength = count($c14);
                                    for ($i=0; $i < $arrlength; $i++) {
                                      echo $c14[$i]."<br/>";
                                    } ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

        </div>
      </div>
    </div>

    <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse2"><h2>Dataset</h2></a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <div class="panel-body">
              <div class="col-lg-12">

                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Nama</th>
                                        <th>Nilai Matapelajaran</th>
                                        <th>Nilai Pramuka</th>
                                        <th>Nilai Kedisiplinan</th>
                                        <th>Nilai Kebersihan</th>
                                        <th>Nilai Absensi</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                         <td><?php

                                          $arrlength = count($id);
                                          for ($i=0; $i < $arrlength; $i++) {
                                            echo $id[$i]."<br/>";
                                          } ?> </td>
                                        <td><?php

                                          $arrlength = count($nama);
                                          for ($i=0; $i < $arrlength; $i++) {
                                            echo $nama[$i]."<br/>";
                                          } ?> </td>
                                <td><?php
                                    $arrlength = count($c10);
                                    for ($i=0; $i < $arrlength; $i++) {
                                      echo $nakau[$i]."<br/>";
                                    }?></td>
                                <td><?php
                                    $arrlength = count($c11);
                                    for ($i=0; $i < $arrlength; $i++) {
                                    echo ubah_c11($c11[$i])."<br/>";
                                    $uc11[]= ubah_c11($c11[$i]);

                                    }?></td>
                                <td><?php

                                    $arrlength = count($c12);
                                    for ($i=0; $i < $arrlength; $i++) {
                                      echo ubah_c12($c12[$i])."<br/>";
                                      $uc12[]= ubah_c12($c12[$i]);
                                    }?></td>
                                <td><?php
                                    $arrlength = count($c13);
                                    for ($i=0; $i < $arrlength; $i++) {
                                      echo ubah_c13($c13[$i])."<br/>";
                                      $uc13[]= ubah_c13($c13[$i]);
                                    }?></td>

                                <td><?php
                                    $arrlength = count($c14);
                                    for ($i=0; $i < $arrlength; $i++) {
                                      echo ubah_c14($c14[$i])."<br/>";
                                      $uc14 []= ubah_c14($c14[$i]);
                                    } ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

        </div>
      </div>
    </div>

    <?php


    $connect = mysqli_connect("localhost","root","","tugasakhir");

         if (!$connect) {
          die("Connection Failed:" .mysqli_connect_error());

         }


       $sql = "SELECT * FROM tb_bobot ORDER BY id ASC ";
       $result = mysqli_query($connect, $sql);

        if(mysqli_num_rows($result) > 0)
       {
            while($row = mysqli_fetch_array($result))
            {

              $bobot[] = $row["nilai"];
              $atribut[] = $row["atribut"];
              $mapel[] = $row["mapel"];
            }

        }
       ?>

    <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse3"><h2>Bobot Kriteria Penilaian</h2></a>
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <div class="panel-body">
              <div class="col-lg-12">

                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr><th>Matapelajaran</th>
                                     <th>Atribut</th>
                                     <th>Nilai</th>
                                     </tr>



                                </thead>
                                <tbody>
                                  <tr></tr

                                     <?php
                                    $arrlength = count($bobot);
                                    for ($i=0; $i < $arrlength; $i++) {
                                      echo "<tr><td>".$mapel[$i]."</td><td>".$atribut[$i]."</td><td>".$bobot[$i]."</td></tr>";
                                    } ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

        </div>
      </div>
    </div>




    <div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse4"><h2>Tabel Faktor Ternormalisasi</h2></a>
        </h4>
      </div>
      <div id="collapse4" class="panel-collapse collapse">
        <div class="panel-body">
              <div class="col-lg-12">

                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">

                              <thead>
                                        <th>Nama</th>
                                        <th>Nilai Matapelajaran</th>
                                        <th>Nilai Pramuka</th>
                                        <th>Nilai Kedisiplinan</th>
                                        <th>Nilai Kebersihan</th>
                                        <th>Nilai Absensi</th>
                              </thead>

                              <tr><td>
                                 <?php
                                  $arrlength = count($nama);
                                  for ($i=0; $i < $arrlength; $i++) {

                                    echo $nama[$i]."<br/>";
                                  }?></td>
                              <td>
                                 <?php
                                  $max = max($nakau);
                                  for ($i=0; $i < $arrlength; $i++) {
                                    $mkc1[] =($nakau[$i] / $max);
                                    echo number_format($mkc1[$i],2)."<br/>";
                                  }?></td>
                              </td>
                              <td><?php $max = max($uc11);

                                  for ($i=0; $i < $arrlength; $i++) {
                                    $mkc11[] =( $uc11[$i] / $max );

                                    echo number_format($mkc11[$i],2)."<br/>";
                                  } ?></td>
                              <td><?php $max = max($uc12);

                                  for ($i=0; $i < $arrlength; $i++) {
                                    $mkc12[] =( $uc12[$i] / $max );
                                    echo number_format($mkc12[$i],2)."<br/>";
                                  } ?></td>
                              <td><?php $max = max($uc13);

                                  for ($i=0; $i < $arrlength; $i++) {
                                    $mkc13[] =( $uc13[$i] / $max );
                                    echo number_format($mkc13[$i],2)."<br/>";
                                  } ?></td>
                              <td><?php $min = min($uc14);

                                  for ($i=0; $i < $arrlength; $i++) {
                                    $mkc14[] =(  $min  / $uc14[$i] );
                                    echo number_format($mkc14[$i],2)."<br/>";
                                  } ?></td>

                                  </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

        </div>
      </div>
    </div>



<div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse6"><h2>Tabel Faktor Ternormalisasi Dikali Bobot</h2></a>
        </h4>
      </div>
      <div id="collapse6" class="panel-collapse collapse">
        <div class="panel-body">
              <div class="col-lg-12">

                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">

                              <thead>
                                        <th>Nama</th>
                                        <th>Nilai Matapelajaran</th>
                                        <th>Nilai Pramuka</th>
                                        <th>Nilai Kedisiplinan</th>
                                        <th>Nilai Kebersihan</th>
                                        <th>Nilai Absensi</th>
                              </thead>

                              <tr><td>
                                 <?php
                                  $arrlength = count($nama);
                                  for ($i=0; $i < $arrlength; $i++) {

                                    echo $nama[$i]."<br/>";
                                  }?></td>
                              <td>
                                 <?php
                                  for ($i=0; $i < $arrlength; $i++) {
                                    $mkbc1[]= number_format($mkc1[$i]*$bobot[0],2);

                                   echo $mkbc1[$i]."<br/>";
                                  }?></td>
                              <td><?php
                                  for ($i=0; $i < $arrlength; $i++) {
                                    $mkbc11[]= number_format($mkc11[$i]*$bobot[1],3);

                                   echo $mkbc11[$i]."<br/>";
                                  }?></td>
                               <td><?php
                                  for ($i=0; $i < $arrlength; $i++) {
                                    $mkbc12[]= number_format($mkc12[$i]*$bobot[2],3);

                                   echo $mkbc12[$i]."<br/>";
                                  }?></td>
                                  <td><?php
                                  for ($i=0; $i < $arrlength; $i++) {
                                    $mkbc13[]= number_format($mkc13[$i]*$bobot[3],3);

                                   echo $mkbc13[$i]."<br/>";
                                  }?></td>
                                  <td><?php
                                  for ($i=0; $i < $arrlength; $i++) {
                                    $mkbc14[]= number_format($mkc14[$i]*$bobot[3],3);

                                   echo $mkbc14[$i]."<br/>";
                                  }?></td>

                                  </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

        </div>
      </div>
    </div>

<div class="panel-group">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse5"><h2>Tabel Hasil Akhir</h2></a>
        </h4>
      </div>
      <div id="collapse5" class="panel-collapse collapse">
        <div class="panel-body">
              <div class="col-lg-12">

                        <div class="table-responsive">
                            <table id="hasil" class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                         <th>Nis</th>
                                        <th>Nama</th>
                                        <th>Hasil Akhir</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php

                                    $arrlength = count($nama);
                                    for ($i=0; $i < $arrlength; $i++) {

                                      $mkbchasil[] = $mkbc1[$i]+$mkbc11[$i]+$mkbc12[$i]+$mkbc13[$i]+$mkbc14[$i];
                                      echo "<tr><td></td><td>".$nis[$i]."</td><td>".$nama[$i]."</td><td>".$mkbchasil[$i]."</td></tr>";
                                    }?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

        </div>
      </div>
    </div>
    <?php   }else{
         echo "<div class='col-lg-12'>";
         echo "Data ditemukan Sejumlah".$record."Namun Kurang Dari 30";

       }

       ?>





<?php }  else {
  echo "<div class='col-lg-12'>";
         echo "Data tidak ditemukan ";
         echo "<br/> Username   : ".$uname;
         echo "<br/> Tahun Ajar:".$tahunajar;
         echo "<br/> Semester   :".$semester;
         echo "</div>";
}
?>

<?php
function ubah_naka($nilai){
     if ($nilai >=90.0 AND $nilai <=100) {
       $hasil = 7;
     }elseif ($nilai >=80.0 AND $nilai <=89.9) {
       $hasil = 6;
     }elseif ($nilai >=70.0 AND $nilai <=79.9) {
       $hasil = 5;
     }elseif ($nilai >=60.0 AND $nilai <=69.9) {
       $hasil = 4;
     }elseif ($nilai >=50.0 AND $nilai <=59.9) {
       $hasil = 3;
     }elseif ($nilai >=40.0 AND $nilai <=49.9) {
       $hasil = 2;
     }

    return $hasil ;
}
function ubah_c11($nilai){

    if ($nilai == "A") {
      $hasil = 9;
    }
     if ($nilai == "B+") {
      $hasil = 7;
    }
     if ($nilai == "B") {
      $hasil = 6;
    }
     if ($nilai == "C+") {
      $hasil = 5;
    }
     if ($nilai == "C") {
      $hasil = 4;
    }
     if ($nilai == "D") {
      $hasil =3;
    }
    return $hasil ;
}
function ubah_c12($nilai){

    if ($nilai == "A") {
      $hasil = 8;
    }
     if ($nilai == "B+") {
      $hasil = 7;
    }
     if ($nilai == "B") {
      $hasil = 6;
    }
     if ($nilai == "C+") {
      $hasil = 5;
    }
     if ($nilai == "C") {
      $hasil = 4;
    }
    return $hasil ;
}
function ubah_c13($nilai){

    if ($nilai == "A") {
      $hasil =7;
    }
     if ($nilai == "B+") {
      $hasil = 6;
    }
     if ($nilai == "B") {
      $hasil = 5;
    }
     if ($nilai == "C+") {
      $hasil = 4;
    }
     if ($nilai == "C") {
      $hasil = 3;
    }
     if ($nilai == "D") {
      $hasil = 2;
    }
    return $hasil ;
}
function ubah_c14($nilai){

    if ($nilai >= 0 && $nilai <= 3) {
      $hasil = 8;
    }
     if ($nilai >= 4 && $nilai <=6) {
      $hasil = 7;
    }
     if ($nilai >= 7 ) {
      $hasil = 6;
    }
    return $hasil ;
}


?>
<script type="text/javascript">
  $(document).ready(function() {
         $('#hasil').DataTable({

                    "aaSorting": [[ 3, "desc" ]]
                });
    var t = $('#hasil').DataTable( {
        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0
        } ],
        "order": [[ 1, 'asc' ]]
    } );
t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();




});
</script>
