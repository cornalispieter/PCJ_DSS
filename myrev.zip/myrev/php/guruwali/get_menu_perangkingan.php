
 <div class="form-group">
 	<h3>Pilih Data Siswa Sebagai Berikut :</h3>
                                <label>Tahun Ajar</label>
                                <select id="tahunajar"class="form-control">
                               <?php get_tahunajar();?>
                                </select>
                        </div>
                        <div class="form-group">
                                <label>Kelas</label>
                                <select id="kelas"class="form-control">
                                    <option value="X">X</option>
                                    <option value="XI-IPA">XI-IPA</option>
                                     <option value="XI-IPS">XI-IPS</option>
                                      <option value="XII-IPA">XII-IPA</option>
                                       <option value="XII-IPS">XII-IPS</option>

                                </select>

                        </div>
                         <div class="form-group">
                                <label>Semester</label>
                                <select id="semester"class="form-control">
                                    <option>I</option>
                                    <option>II</option>
                                </select>

                        </div>

                        <div>
                        	<button id="btn-pilih-data">Pilih Data</button>
                        </div>
     <script src="/myrev/js/guruwali/getdatasiswa.js"></script>

 <?php
     	function get_tahunajar(){


  $connect = mysqli_connect("localhost","root","","tugasakhir");

   if (!$connect) {
    die("Connection Failed:" .mysqli_connect_error());

   }


 $sql = "SELECT DISTINCT tahunajar FROM tb_data_siswa ";
 $result = mysqli_query($connect, $sql);
 if(mysqli_num_rows($result) > 0)
 {
      while($row = mysqli_fetch_array($result))
      {

      		echo "<option value=".$row['tahunajar'].">".$row['tahunajar']."</option>";


      }
} else {



 }
}
     ?>
