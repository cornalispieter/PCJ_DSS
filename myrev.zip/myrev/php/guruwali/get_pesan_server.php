<?php
                   session_start();
                    				$servername = "localhost";
									$username = "root";
									$password = "";
									$dbname = "tugasakhir";

									$conn = mysqli_connect($servername,$username,$password,$dbname);

									 if (!$conn) {
									 	die("Connection Failed:" .mysqli_connect_error());
									 }
                    				$sql = "SELECT pesan from tb_pesan_server WHERE role='".$_SESSION["job_desk"]."'";
                    				$result = mysqli_query($conn,$sql);
									$num_row = mysqli_num_rows($result);
									if ($num_row > 0) {
										$data = mysqli_fetch_array($result);
								 		echo $data["pesan"];
									}else
									{
										echo "no data !";
									}

                    			?>
