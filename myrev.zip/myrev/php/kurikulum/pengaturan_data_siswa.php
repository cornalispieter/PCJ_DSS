<form>
	<h3>Menu Pengaturan Data Siswa</h3>

		<button type="button" id="input-data" class="btn btn-primary">Input Data Siswa Tahun Ajaran Baru</button>
	
		<button type="button" id="cari-data" class="btn btn-primary">Cari Data Siswa</button>
</form>

<script type="text/javascript">
	$(document).ready(function(){
		function inputsiswa(){
			$.ajax({
            url: '/myrev/php/kurikulum/request/input-data.php',
            method: 'POST',
            dataType:'text',
            success: function(data){
              if (data) {
               $("#body_output").html(data);
              } else{
                alert("No Data Has Been Found !");
              };
            }
        });
		}
		function caridata(){
			$.ajax({
            url: '/myrev/php/kurikulum/request/cari_data.php',
            method: 'POST',
            dataType:'text',
            success: function(data){
              if (data) {
               $("#body_output").html(data);
              } else{
                alert("No Data Has Been Found !");
              };
            }
        });
		}
		$("#input-data").click(function(){
		inputsiswa();
	});
		$("#cari-data").click(function(){
		caridata();
	});
	});
	
</script>


