<?php

  $connect = mysqli_connect("localhost","root","","tugasakhir");

   if (!$connect) {
    die("Connection Failed:" .mysqli_connect_error());

   }
   $id = $_POST['id'];
  $output = '';
 $sql = "SELECT * FROM tb_data_siswa WHERE  id='".$id."'";
 $result = mysqli_query($connect, $sql);
 if(mysqli_num_rows($result) > 0)
 {
      while($row = mysqli_fetch_array($result))
      { ?>


        <div id="form_edit_guru_wali">
          <label for="disabledSelect">Nama Siswa</label>
          <input type="hidden" name="id"value="<?php echo $row["id"];?>">
          <input class="form-control" id="namasiswa" type="text" value="<?php echo $row["nama"];?> " disabled>
           <label >Guru Wali</label>
           <select id="txt-username" class="form-control">
              <option><?php echo $row["username"];?></option>
              <?php get_option();?>
           </select>
           <button  id="btn-update-grw">Update</button>

         </div>
         <div id="out"></div>

<script type="text/javascript" >
  $(document).ready(function(){
     var id = $('input[name=id]').val();
  var username = "";




 $("#txt-username").change(function() {
    //alert($(this).find("option:selected").text()+' clicked!');
    var username = $(this).find("option:selected").text();

  $("#btn-update-grw").click(function(){




        $.ajax({
                url:"/myrev/php/kurikulum/request/edit_guruwali.php",
                method:"POST",
                data:{id:id, username:username},
                dataType:"text",
                success:function(data){
                     alert(data);
                       refresh();
                }
           });

    });
});
function refresh(){
      $.ajax({
        url: '/myrev/php/kurikulum/pengaturan_guruwali.php',
        method: 'POST',
        dataType:'text',
        success: function(data){
          if (data) {
           $("#body_output").html(data);
           $("#body_output").effect("shake");
          } else{
            alert("No Data Has Been Found !");

          };
        }
      });
    }

});



</script>


<?php      }
}

function get_option(){
   $connect = mysqli_connect("localhost","root","","tugasakhir");

   if (!$connect) {
    die("Connection Failed:" .mysqli_connect_error());

   }

  $output = '';
 $sql = "SELECT * FROM user WHERE  id_user like '%GRW%' ";
 $result = mysqli_query($connect, $sql);
 if(mysqli_num_rows($result) > 0)
 {
   while($rw = mysqli_fetch_array($result))
      { ?>
    <option value="<?php echo $rw["username"];?>"><?php echo $rw["username"];?></option>
 <?php }
 }
}
?>
