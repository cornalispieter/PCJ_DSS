<script src="/myrev/js/kurikulum/edit_user.js"></script>
 <?php

 $connect = mysqli_connect("localhost", "root", "", "tugasakhir");  
 $id = $_POST["id"];
 $sql = "SELECT * from user WHERE id='$id'";
$result = mysqli_query($connect, $sql);
 if(mysqli_num_rows($result) > 0)
 {
      while($row = mysqli_fetch_array($result))
      { ?>

      	<form>
		<table>
		<tr>
			<td><h2>Form Update User</h2></td>
		</tr>

			<td><label>id</label><input id="idusername" type="text"  value="<?php echo $row["id"];?>"  disabled></td>
		<tr>
			<td><label for="disabledSelect">Username</label>
			<input type="text" id="username" value="<?php echo $row["username"]?>"></td>
		</tr>

		<tr>
			<td><label for="disabledSelect">Password</label>
			<input type="password" id="password" placeholder="<?php echo $row["password"]?>"></td>
		</tr>
		<tr><td><label for="disabledSelect">Job Desk </label>
			<select id="job_desk">
			<option val="1">KURIKULUM</option>
			<option val="2">GURU WALI</option>
			<option val="3">GURU PENGAJAR</option>
			</select></td>
		</tr>
		<tr>
		<td>
			<button id="btn-update-user" class="glyphicon glyphicon-floppy-disk">Update</button>
			<button id="btn-cancel-edit-user" class="glyphicon glyphicon-triangle-left">Cancel</button>
		<td>
			</tr>
		</table>
		</form>



 <?php      }
}
 ?>
