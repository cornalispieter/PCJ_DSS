<?php

  $connect = mysqli_connect("localhost","root","","tugasakhir");

   if (!$connect) {
    die("Connection Failed:" .mysqli_connect_error());

   }

 $tahunajar = $_POST["tahunajar"];
 $kelas = $_POST["kelas"];
 $semester = $_POST["semester"];


 $sql = "SELECT * FROM tb_data_siswa WHERE  tahunajar='".$tahunajar."' AND kelas='".$kelas."' AND semester='".$semester."'";
 $result = mysqli_query($connect, $sql);   ?>
 <div class="table-responsive">
 <table id="daftarnilai" class= "table table-bordered">
  <THEAD>

  <h4>Kelas : <?php echo $kelas;?></h4>
  <h4>Semester : <?php echo $semester;?></h4>
   <h4>Tahun Ajar : <?php echo $tahunajar;?></h4>
    <tr>
      <td>No</td>
      <td>Nis</td>
      <td>Nama</td>
      <td>Kelas</td>
      <td>Tahun Ajar</td>
      <td>Guru Wali</td>
      <td>Opsi</td>
    </tr>

  </THEAD>

 <?php if(mysqli_num_rows($result) > 0)

 {
      while($row = mysqli_fetch_array($result))
      {  ?>

      <tr>
      <td></td>
      <td><?php echo $row['nis'];?></td>
      <td><?php echo $row['nama'];?></td>
      <td><?php echo $row['kelas'];?></td>
      <td><?php echo $row['tahunajar'];?></td>
       <td><?php echo $row['username'];?></td>
      <td align="center"><button id="edit" type="button"  data-id1="<?php echo $row["id"];?>" class="btn btn-primary">
      <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></button>
      <button id="hapus" type="button"  data-id2="<?php echo $row["id"];?>" class="btn btn-danger">
      <span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
      </td>
      </tr>

<?php      }

  } else{

    echo "data not found";
  }  ?>
</table>
  </div>



  <script type="text/javascript">
    $(document).ready(function(){



 var t = $('#daftarnilai').DataTable( {
        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0
        } ],
        "order": [[ 1, 'asc' ]]
    } );;
t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
        $("#cancel").click(function(){
          refresh();
        });

$(document).on('click','#edit',function(){
  var id=$(this).data("id1");

            $.ajax({
      url:"/myrev/php/kurikulum/request/editshowformsiswa.php",
      method:"POST",
      data:{id:id},
      dataType:"text",
      success:function(data){
      $("#body_output").html(data);
                     }
    });

});
$(document).on('click','#hapus',function(){
  var id=$(this).data("id2");

            $.ajax({
      url:"/myrev/php/kurikulum/request/hapussiswa.php",
      method:"POST",
      data:{id:id},
      dataType:"text",
      success:function(data){
      $("#body_output").html(data);
      back();
                     }
    });

});
function back(){
            $.ajax({
            url: '/myrev/php/kurikulum/pengaturan_data_siswa.php',
            method: 'POST',
            dataType:'text',
            success: function(data){
              if (data) {
               $("#body_output").html(data);
              } else{
                alert("No Data Has Been Found !");
              };
            }
        });
        }

    });

  </script>
