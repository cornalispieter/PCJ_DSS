                    <div class="table-responsive">
                    <h4>Masukan Data Siswa Sebagai Berikut</h4>
                         <table class="table table-bordered table-hover">
                             <tr>
                                 <td>Nomor Induk Siswa</td>
                                 <td>:</td>
                                 <td><input type="text" id="nis" maxlength="4" size="4"></td>
                             </tr>
                             <tr>
                                 <td>Nama</td>
                                 <td>:</td>
                                 <td><input type="text" id="nama" maxlength="200" size="30"></td>
                             </tr>
                             <tr>
                                 <td>Tahun Ajaran</td>
                                 <td>:</td>
                                 <td>
                                     <select id="thstart"><?php tahun();?></select> / <select id="thend"><?php tahun2();?></select>

                                 </td>
                             </tr>
                             <tr>
                                 <td>Kelas</td>
                                 <td>:</td>
                                 <td>
                                    <select id="kelas" class="form-control">
                                    <option value="X">X</option>
                                    <option value="XI-IPA">XI-IPA</option>
                                    <option value="XI-IPS">XI-IPS</option>
                                    <option value="XII-IPA">XII-IPA</option>
                                    <option value="XII-IPS">XII-IPS</option>
                                    </select>

                                 </td>
                             </tr>
                             <tr>
                                 <td>Semester</td>
                                 <td>:</td>
                                 <td>
                                    <select id="semester" class="form-control">
                                    <option value="I">I</option>
                                    <option value="II">II</option>
                                    </select>

                                 </td>
                             </tr>
                             <tr>
                                 <td>Guru Wali</td>
                                 <td>:</td>
                                 <td>
                                    <select id="guruwali" class="form-control">
                                    <?php get_option();?>
                                    </select>

                                 </td>
                             </tr>
                            <tr>
                                <td colspan="3" align="right">
                                    <button id="simpan" class="btn btn-primary">Simpan</button>
                                    <button id="batal" class="btn btn-primary">Batal</button>
                                </td>
                            </tr>

                         </table>
                    </div>

    <?php
        function tahun(){
            $already_selected_value = 2012;
            $earliest_year = 2012;
            foreach (range(date('Y'), $earliest_year) as $x) {
             print '<option value="'.$x.'"'.($x === $already_selected_value ? ' selected="selected"' : '').'>'.$x.'</option>';
            }
        }
        function tahun2(){
            $already_selected_value = 2013;
            $earliest_year = 2013;
            foreach (range(date('Y'), $earliest_year) as $x) {
             print '<option value="'.$x.'"'.($x === $already_selected_value ? ' selected="selected"' : '').'>'.$x.'</option>';
            }
        }

    ?>

    <script type="text/javascript">
       $(document).ready(function(){
         function back(){
            $.ajax({
            url: '/myrev/php/kurikulum/pengaturan_data_siswa.php',
            method: 'POST',
            dataType:'text',
            success: function(data){
              if (data) {
               $("#body_output").html(data);
              } else{
                alert("No Data Has Been Found !");
              };
            }
        });
        }
        function simpan(){

            var nis = $("#nis").val();
            var nama = $("#nama").val();
            var thstart = $("#thstart").val();
            var thend = $("#thend").val();
            var kelas = $("#kelas").val();
            var semester = $("#semester").val();
            var username = $("#guruwali").val();
            if (nis == "") {
                alert("Nomor Induk Siswa harus di isi")
                $("#nis").focus();
            }else{
               $.ajax({
                url:"/myrev/php/kurikulum/request/simpansiswa.php",
                method:"POST",
                data:{nis:nis, nama:nama, thstart:thstart, thend:thend, kelas:kelas, semester:semester, username:username},
                dataType:"text",
                success:function(data)
                {
                     alert(data);
                     back();
                }


           })
            }

        }
        $("#batal").click(function(){
            back();
        });
        $("#simpan").click(function(){
           simpan();
        });
       });
    </script>

<?php
function get_option(){
   $connect = mysqli_connect("localhost","root","","tugasakhir");

   if (!$connect) {
    die("Connection Failed:" .mysqli_connect_error());

   }

  $output = '';
 $sql = "SELECT * FROM user WHERE  id_user like '%GRW%' ";
 $result = mysqli_query($connect, $sql);
 if(mysqli_num_rows($result) > 0)
 {
   while($rw = mysqli_fetch_array($result))
      { ?>
    <option value="<?php echo $rw["username"];?>"><?php echo $rw["username"];?></option>
 <?php }
 }
}
?>
