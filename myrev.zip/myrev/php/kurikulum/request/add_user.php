<form>
<table>
<tr>
	<td><h2>Form Add User</h2></td>
</tr>
<tr>
	<td><label for="disabledSelect">Username</label>
	<input type="text" id="username"></td>
</tr>

<tr>
	<td><label for="disabledSelect">Password</label>
	<input type="password" id="password" value=""></td>
</tr>
<tr><td><label for="disabledSelect">Job Desk </label>
	<select id="job_desk"> <br/>
	<option val="KUR">KURIKULUM</option>
	<option val="GRW">GURU WALI</option>
	<option val="GRP">GURU PENGAJAR</option>
	</select></td>
</tr>
<tr>
<td>
	<button id="btn-save-user" class="glyphicon glyphicon-floppy-disk">Save</button>
	<button id="btn-cancel-add-user" class="glyphicon glyphicon-triangle-left">Cancel</button>
<td>
	</tr>
</table>
</form>
     
<script type="text/javascript" src="/myrev/js/kurikulum/progres_del_add_user.js"></script>