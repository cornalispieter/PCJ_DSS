<?php
 $connect = mysqli_connect("localhost", "root", "", "tugasakhir");  
 $nis=$_POST["nis"];
 $nama=$_POST["nama"];
 $tahunajar=$_POST["thstart"]."/".$_POST["thend"];
 $kelas=$_POST["kelas"];
 $semester=$_POST["semester"];
 $username=$_POST["username"];

      $sql = " INSERT INTO tb_data_siswa (id,nama,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,tahunajar,semester,kelas,username,nis) VALUES (null,'$nama',null,null,null,null,null,null,null,null,null,null,null,null,null,null,'$tahunajar','$semester','$kelas','$username','$nis')";

       if(mysqli_query($connect, $sql))
 {
      echo 'Data Inserted';
 }


 ?>
