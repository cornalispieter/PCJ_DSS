<?php
 $connect = mysqli_connect("localhost", "root", "", "tugasakhir");  
 $nis=$_POST["nis"];
 $nama=$_POST["nama"];
 $tahunajar=$_POST["thstart"]."/".$_POST["thend"];
 $kelas=$_POST["kelas"];
 $semester=$_POST["semester"];
 $username=$_POST["username"];

      $sql = "UPDATE tb_data_siswa SET nama='$nama', tahunajar='$tahunajar', kelas='$kelas', semester='$semester', username='$username' WHERE nis='$nis'";

       if(mysqli_query($connect, $sql))
 {
      echo 'Data Berhasil Diubah !';
 }


 ?>
