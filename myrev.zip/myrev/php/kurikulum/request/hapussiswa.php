<?php
 $connect = mysqli_connect("localhost", "root", "", "tugasakhir");  
 $sql = "DELETE FROM tb_data_siswa WHERE id = '".$_POST["id"]."'";
 if(mysqli_query($connect, $sql))
 {
      echo 'Data Deleted';
 }
 ?>
