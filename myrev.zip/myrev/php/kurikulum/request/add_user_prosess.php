<?php
 $connect = mysqli_connect("localhost", "root", "", "tugasakhir");  
 $username =$_POST["username"];
 $password =$_POST["password"];
 $job_desk =$_POST["job_desk"];

 	if ($job_desk == "GURU WALI") {
 		$jd = "2";
 		$id_user = "GRW";
 	}
 	if ($job_desk == "KURIKULUM") {
 		$jd = "1";
 		$id_user = "KUR";
 	}
 	if ($job_desk == "GURU PENGAJAR") {
 		$jd = "3";
 		$id_user = "GRP";
 	}



      $sql = " INSERT INTO `user` (`id`, `id_user`, `username`, `password`, `job_desk`) VALUES (NULL,
      '".$id_user."', '".$username."', '".md5($password)."', '".$jd."'); ";

       if(mysqli_query($connect, $sql))
 {
      echo 'Data Inserted';
 }

 ?>
