 <?php
 $connect = mysqli_connect("localhost", "root", "", "tugasakhir");  
 $id = $_POST["id"];
 $username = $_POST["username"];


	$sql = "UPDATE tb_data_siswa SET username='".$username."' WHERE id='".$id."'";
 	if(mysqli_query($connect, $sql))
 	{
      echo 'Data Updated';
 	}




 ?>
