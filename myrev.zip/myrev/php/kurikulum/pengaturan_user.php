<?php

	$connect = mysqli_connect("localhost","root","","tugasakhir");

	 if (!$connect) {
	 	die("Connection Failed:" .mysqli_connect_error());

	 }
	$output = '';
 $sql = "SELECT * FROM user ORDER  BY id asc";
 $result = mysqli_query($connect, $sql);  ?>

      <div class="table-responsive">
           <table class="table table-bordered">
                <tr>

                     <th width="40%">Username</th>
                     <th width="40%">Id User</th>
                     <th width="40%">Password</th>
                     <th width="40%">Job Desk</th>

                     <th width="10%">Option</th>
                </tr>
<?php if(mysqli_num_rows($result) > 0)
 {
      while($row = mysqli_fetch_array($result))
      {  ?>

            <tr>
                <td  ><?php echo $row["username"];?></td>
                <td  ><?php echo $row["id_user"];?></td>
                <td  ><?php echo $row["password"];?></td>
                <td  ><?php echo $row["job_desk"];?></td>
                <td><button type="button" id="btn-del-user"
                data-id3="<?php echo $row['id'];?>" class="glyphicon glyphicon-remove"></button>

                </td>
           </tr>
   <?php   }   ?>


 <?php }  ?>
 <tr>
   <td><button type="button" id="btn-add-user"
              " class="glyphicon glyphicon-plus">Add User</button></td>
 </tr>
</table>
      </div>

<script type="text/javascript" src="/myrev/js/kurikulum/progres_del_add_user.js"></script>
