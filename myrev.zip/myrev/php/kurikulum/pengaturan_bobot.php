<?php

  $connect = mysqli_connect("localhost","root","","tugasakhir");

   if (!$connect) {
    die("Connection Failed:" .mysqli_connect_error());

   }
   $total_bobot = 0;
  $output = '';
 $sql = "SELECT * FROM tb_bobot ORDER  BY id asc";
 $result = mysqli_query($connect, $sql);  ?>

      <div class="table-responsive">
        <h2> Bobot Kriteria Penilaian Siswa</h2>
           <table class="table table-bordered">
                <tr>

                     <th width="40%">Matapelajaran</th>
                     <th width="40%">Atribut</th>
                     <th width="40%">Nilai Bobot</th>

                </tr>
<?php if(mysqli_num_rows($result) > 0)
 {
      while($row = mysqli_fetch_array($result))
      {  ?>

            <tr>

                     <td class="matapelajaran"><?php echo $row["mapel"]; ?></td>
                     <td class="atribut"  ><?php echo $row["atribut"]; ?></td>
                      <td class="nilai" data-id1="<?php echo $row["id"]; ?>" contenteditable><?php echo $row["nilai"];?></td>

                </tr>
   <?php
        $total_bobot = $total_bobot + $row['nilai'];
         }   ?>
             <tr>
              <td id="username" contenteditable colspan="2" align="right"> Jumlah Bobot : </td>

                <td><?php echo $total_bobot;?></td>
           </tr>

 <?php }  ?>

</table>
      </div>

<script type="text/javascript" >



     function edit_data(id, text, column_name)
      {
           $.ajax({
                url:"/myrev/php/kurikulum/request/editbobot.php",
                method:"POST",
                data:{id:id, text:text, column_name:column_name},
                dataType:"text",
                success:function(data){
                 reload();


                }
           });
      }

  $(document).on('blur','.nilai', function(){
           var id = $(this).data("id1");
           var nilai = $(this).text();
           edit_data(id,nilai, "nilai");
      });

  function reload(){


            $.ajax({
                url: '/myrev/php/kurikulum/pengaturan_bobot.php',
                method: 'POST',
                dataType:'text',
                success: function(data){
                  if (data) {
                   $("#body_output").html(data);

                  } else{
                    alert("No Data Has Been Found !");

                  };
                }
              });
  }



</script>
