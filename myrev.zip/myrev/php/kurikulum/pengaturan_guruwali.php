<?php

  $connect = mysqli_connect("localhost","root","","tugasakhir");

   if (!$connect) {
    die("Connection Failed:" .mysqli_connect_error());

   }
  $output = '';
 $sql = "SELECT * FROM tb_data_siswa ORDER  BY id asc";
 $result = mysqli_query($connect, $sql);
 $angka = 0;
 $output .= '
      <div class="table-responsive">
          <h2>Form Update Guru Wali</h2>
           <table class="table table-bordered">
                <tr>

                     <th width="2%">No</th>
                     <th width="30%">Nama</th>
                     <th width="10%">Kelas</th>
                     <th width="10%">Semester</th>
                     <th width="10%">Tahun Ajar</th>
                     <th width="10%">Guru Wali</th>
                     <th width="10%">Edit</th>
                </tr>';
 if(mysqli_num_rows($result) > 0)
 {
      while($row = mysqli_fetch_array($result))
      {
        $angka = $angka +1 ;
           $output .= '
                <tr>

                     <td>'.$angka.'</td>
                     <td class="nama" data-id2="'.$row["id"].'" >'.$row["nama"].'</td>
                      <td class="kelas" data-id3="'.$row["id"].'" >'.$row["kelas"].'</td>
                      <td class="semester" data-id1="'.$row["id"].'" >'.$row["semester"].'</td>
                     <td class="tahunajar" data-id2="'.$row["id"].'" >'.$row["tahunajar"].'</td>
                      <td class="id_user" data-id3="'.$row["id"].'" >'.$row["username"].'</td>
                     <td><button type="button" id="edit-wali-btn" data-id4="'.$row["id"].'" class="glyphicon glyphicon-pencil">Edit</button></td>
                </tr>
           ';
      }
      $output .= '
           <tr>

           </tr>
      ';
 }
 else
 {
      $output .= '<tr>
                          <td colspan="4">Data not Found</td>
                     </tr>';
 }
 $output .= '</table>
      </div>';
 echo $output;
 ?>
 <script type="text/javascript">


$(document).ready(function(){
$(document).on('click', '#edit-wali-btn', function(){
           var id = $(this).data("id4");
         if(confirm("Are you sure you want to edit this?"))
           {
                $.ajax({
                     url:"/myrev/php/kurikulum/request/request_datasiswa_byid.php",
                     method:"POST",
                     data:{id:id},
                     dataType:"text",
                     success:function(data){
                          $("#body_output").html(data);
                     }
                });
           }

      });

});






 </script>
