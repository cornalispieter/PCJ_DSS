<?php
session_start();
if (!isset($_SESSION["username"])) {
	header("location:http://localhost/myrev/index.php");
}
	

?>


    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Sistem Pendukung Keputusan</a>

            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $_SESSION["username"];?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        
                        <li class="divider"></li>
                        <li>
                            <a href="http://localhost/myrev/php/logout/logout.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                       <a href="#" id="dashboard"> <i class="glyphicon glyphicon-th-large"></i> Dashboard</a>
                    </li>
                    <li>
                      <a href="#" id="pengaturan-user">  <i class="glyphicon glyphicon-user"></i> Pengaturan User</a>
                    </li>
                    <li>
                       <a href="#" id="pengaturan-bobot">  <i class="glyphicon glyphicon-wrench" ></i> Pengaturan Bobot</a>
                    </li>
                    <li>

                       <a href="#" id="pengaturan-data-siswa">  <i class="glyphicon glyphicon-equalizer" ></i> Pengaturan Data Siswa </a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                             <p><img src="/myrev/media/logo/smaimmanuel.jpg" width="40" height="50"> SMA IMMANUEL BATU</p>
                                
                                <h3>Bagian Kurikulum</h3> 
                           
                        </h1>
                    </div>
                </div>
                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="panel panel-default">
                            <div class="panel-body" align="justify" id="body_output">
                                

				            </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->

                
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <script type="text/javascript">
        $(document).ready(function(){
            function refresh(){
            $.ajax({
            url: '/myrev/php/kurikulum/request/get_pesan.php',
            method: 'POST',
            dataType:'text',
            success: function(data){
              if (data) {
               $("#body_output").html(data);
              } else{
                alert("No Data Has Been Found !");
              };
            }
        });
        }
        function get_pengaturan_user(){

        $.ajax({
            url: '/myrev/php/kurikulum/pengaturan_user.php',
            method: 'POST',
            dataType:'text',
            success: function(data){
              if (data) {
               $("#body_output").html(data);
                $("#body_output").effect("shake");
              } else{
                alert("No Data Has Been Found !");

              };
            }
          });
        }
        function get_pengaturan_bobot(){

            $.ajax({
                url: '/myrev/php/kurikulum/pengaturan_bobot.php',
                method: 'POST',
                dataType:'text',
                success: function(data){
                  if (data) {
                   $("#body_output").html(data);
                   $("#body_output").effect("shake");
                  } else{
                    alert("No Data Has Been Found !");

                  };
                }
              });
          }
        function get_pengaturan_data_siswa(){
           $.ajax({
                url: '/myrev/php/kurikulum/pengaturan_data_siswa.php',
                method: 'POST',
                dataType:'text',
                success: function(data){
                  if (data) {
                   $("#body_output").html(data);
                   $("#body_output").effect("shake");
                  } else{
                    alert("No Data Has Been Found !");

                  };
                }
              }); 
        }
        
        refresh();
        
        $("#dashboard").click(function(){
            refresh();
        });
        $("#pengaturan-user").click(function(){
            get_pengaturan_user();
        });
        $("#pengaturan-bobot").click(function(){
            get_pengaturan_bobot();
        });

        $("#pengaturan-data-siswa").click(function(){
            get_pengaturan_data_siswa();
        });

        });

    </script>
    