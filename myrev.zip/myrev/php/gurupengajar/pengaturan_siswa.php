
 <div class="form-group">
 	<h3>Pilih Data Siswa Sebagai Berikut :</h3>
                                <label>Tahun Ajar</label>
                                <select id="tahunajar"class="form-control">
                               <?php get_tahunajar();?>
                                </select>
                        </div>
                         <div class="form-group">
                                <label>Kelas</label>
                                <select id="kelas"class="form-control">
                                    <option value="X">X</option>
                                    <option value="XI-IPA">XI-IPA</option>
                                     <option value="XI-IPS">XI-IPS</option>
                                      <option value="XII-IPA">XII-IPA</option>
                                       <option value="XII-IPS">XII-IPS</option>

                                </select>

                        </div>
                         <div class="form-group">
                                <label>Semester</label>
                                <select id="semester"class="form-control">
                                    <option value="I">I</option>
                                    <option value="II">II</option>
                                </select>

                        </div>
                        <div class="form-group">
                                <label>Matapelajaran</label>
                                <select id="matapelajaran"class="form-control">
                                                <?php get_matapelajaran(); ?>
                                </select>

                        </div>
                        <div>
                        	<button id="btn-pilih-data">Pilih Data</button>
                        </div>


 <?php
     	function get_tahunajar(){


  $connect = mysqli_connect("localhost","root","","tugasakhir");

   if (!$connect) {
    die("Connection Failed:" .mysqli_connect_error());

   }


 $sql = "SELECT DISTINCT tahunajar FROM tb_data_siswa ";
 $result = mysqli_query($connect, $sql);
 if(mysqli_num_rows($result) > 0)
 {
      while($row = mysqli_fetch_array($result))
      {

      		echo "<option value=".$row['tahunajar'].">".$row['tahunajar']."</option>";


      }
} else {



 }
}
  function get_matapelajaran(){


  $connect = mysqli_connect("localhost","root","","tugasakhir");

   if (!$connect) {
    die("Connection Failed:" .mysqli_connect_error());

   }


 $sql = "SELECT *  FROM tb_bobot ";
 $result = mysqli_query($connect, $sql);
 if(mysqli_num_rows($result) > 0)
 {
      while($row = mysqli_fetch_array($result))
      {

          echo "<option value=".$row['atribut'].">".$row['mapel']."</option>";


      }
} else {



 }
}
     ?>

<script type="text/javascript">
  $(document).ready(function(){
    function get_data_siswa(){
     var tahunajar = $("#tahunajar").val();
      var kelas = $("#kelas").val();
     var semester = $("#semester").val();
     var matapelajaran = $("#matapelajaran").val();
     $.ajax({
                url:"/myrev/php/gurupengajar/request/get_data_siswa.php",
                method:"POST",
                data:{ tahunajar:tahunajar, kelas:kelas, semester:semester, matapelajaran:matapelajaran},
                dataType:"text",
                success:function(data){
                     $("#body_output").html(data);
                }
           });
}
$("#btn-pilih-data").click(function(){
    get_data_siswa();
});
  });
</script>
