<?php

  $connect = mysqli_connect("localhost","root","","tugasakhir");

   if (!$connect) {
    die("Connection Failed:" .mysqli_connect_error());

   }

 $id = $_POST["id"];
 $matapelajaran = $_POST["matapelajaran"];



 $sql = "SELECT * FROM tb_data_siswa WHERE  id='".$id."'";
 $result = mysqli_query($connect, $sql);   ?>



 	<h3>Form Pengaturan Nilai Siswa</h3>

 <?php if(mysqli_num_rows($result) > 0)

 {
      while($row = mysqli_fetch_array($result))
      {
          $mapel=$row[$matapelajaran];
       ?>

  		<div class="form-group">
        <label>Nomor Induk Siswa</label>
	    <input id="nis" class="form-control" value="<?php echo $row['nis'];?>" disabled>
	    <input id="matapelajaran" type="hidden" class="form-control" value="<?php echo $matapelajaran ;?>" disabled>
        </div>
        <div class="form-group">
        <label>Nama Siswa</label>
	    <input id="nama" class="form-control" value="<?php echo $row['nama'];?>" disabled>
        </div>
        <div class="form-group">
        <label>Nilai</label>
	         <?php
                if ( $matapelajaran == "c11" OR $matapelajaran == "c12" OR $matapelajaran == "c13"  ) {
                  echo "nilai Sebelumnya : $mapel";
                  nilaihuruf();
                }else{
                  echo "nilai Sebelumnya : $mapel";
                  nilaiangka();
                }
           ?>

        </div>
        <button id="simpan" type="button" class="btn btn-default">Simpan</button>
        <button id="batal" type="button" class="btn btn-default">Batal</button>

      <?php      }

  } else{

    echo "data not found";
  }
  ?>
  <?php
    function nilaihuruf(){ ?>
                              <select id="nilai" class="form-control">

                                    <option value="A">A</option>
                                    <option value="B+">B+</option>
                                    <option value="B">B</option>
                                    <option value="B-">B-</option>
                                    <option value="C+">C+</option>
                                    <option value="C">C</option>
                                    <option value="D">D</option>
                                </select>
   <?php } ?>

   <?php function nilaiangka(){ ?>
      <input id="nilai" class="form-control">
  <?php  }  ?>




  <script type="text/javascript">
  	$(document).ready(function(){
  		function refresh(){

	    $.ajax({
	        url: '/myrev/php/gurupengajar/pengaturan_siswa.php',
	        method: 'POST',
	        dataType:'text',
	        success: function(data){
	          if (data) {
	           $("#body_output").html(data);
	            $("#body_output").effect("shake");
	          } else{
	            alert("No Data Has Been Found !");

	          };
	        }
	      });
	  }

	  function simpan(){
	  	var nis = $("#nis").val();
  		var nilai = $("#nilai").val();
  		var matapelajaran = $("#matapelajaran").val();
  		 $.ajax({
                url:"/myrev/php/gurupengajar/request/simpan_nilai.php",
                method:"POST",
                data:{nis:nis, nilai:nilai, kolom:matapelajaran},
                dataType:"text",
                success:function(data){
                     alert(data);
                       refresh();
                }
           });
	  }

  		$("#batal").click(function(){
  			refresh();
  		});

  		$("#simpan").click(function(){
  				simpan();
  		});

  	});

  </script>
