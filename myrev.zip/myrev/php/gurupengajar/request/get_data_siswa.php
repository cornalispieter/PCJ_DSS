<?php

  $connect = mysqli_connect("localhost","root","","tugasakhir");

   if (!$connect) {
    die("Connection Failed:" .mysqli_connect_error());

   }

 $tahunajar = $_POST["tahunajar"];
 $kelas = $_POST["kelas"];
 $semester = $_POST["semester"];
 $matapelajaran = $_POST["matapelajaran"];


 $sql = "SELECT * FROM tb_data_siswa WHERE  tahunajar='".$tahunajar."' AND kelas='".$kelas."' AND semester='".$semester."'";
 $result = mysqli_query($connect, $sql);   ?>
 <div class="table-responsive">
 <table id="daftarnilai" class= "table table-bordered">
  <THEAD>
  <h4>Daftar Nilai Matapelajaran : <?php echo ubahmapel($matapelajaran);?></h4>
  <h4>Kelas : <?php echo $kelas;?></h4>
  <h4>Semestaer : <?php echo $semester;?></h4>
   <h4>Tahun Ajar : <?php echo $tahunajar;?></h4>
    <tr>
      <td>No</td>
      <td>Nis</td>
      <td>Nama</td>
      <td>Nilai</td>
      <td>Opsi</td>
    </tr>

  </THEAD>

 <?php if(mysqli_num_rows($result) > 0)

 {
      while($row = mysqli_fetch_array($result))
      {  ?>

      <tr>
      <td></td>
      <td><?php echo $row['nis'];?></td>
      <td><?php echo $row['nama'];?></td>
      <td><?php echo $row[$matapelajaran];?></td>
      <td><button id="edit" type="button"  data-id1="<?php echo $row["id"];?>" data-id2="<?php echo $matapelajaran; ?>">
      <span class="glyphicon glyphicon-pencil" aria-hidden="true"></button></span></td>
      </tr>

<?php      }

  } else{

    echo "data not found";
  }  ?>
</table>
  </div>

<?php
  function ubahmapel($mapel){
    if ($mapel == 'c1') {
      echo "AGAMA";
    }elseif ($mapel == 'c2') {
      echo "PKN";
    }elseif ($mapel == 'c3') {
      echo "BAHASA INDONESIA";
    } elseif ($mapel == 'c4') {
      echo "BAHASA INGGRIS";
    } elseif ($mapel == 'c5') {
      echo "MATEMATIKA";
    } elseif ($mapel == 'c6') {
      echo "FISIKA";
    } elseif ($mapel == 'c7') {
      echo "SEJARAH";
    } elseif ($mapel == 'c8') {
      echo "GEOGRAFI";
    } elseif ($mapel == 'c9') {
      echo "EKONOMI";
    } elseif ($mapel == 'c10') {
      echo "KOMPUTER";
    } elseif ($mapel == 'c11') {
      echo "PRAMUKA";
    } elseif ($mapel == 'c12') {
      echo "KEDISIPLINAN";
    } elseif ($mapel == 'c13') {
      echo "KEBERSIHAN";
    } elseif ($mapel == 'c14') {
      echo "ABSENSI";
    }
  }
?>

  <script type="text/javascript">
    $(document).ready(function(){

      function refresh(){

    $.ajax({
        url: '/myrev/php/gurupengajar/pengaturan_siswa.php',
        method: 'POST',
        dataType:'text',
        success: function(data){
          if (data) {
           $("#body_output").html(data);
            $("#body_output").effect("shake");
          } else{
            alert("No Data Has Been Found !");

          };
        }
      });
  }

 var t = $('#daftarnilai').DataTable( {
        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0
        } ],
        "order": [[ 1, 'asc' ]]
    } );;
t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
        $("#cancel").click(function(){
          refresh();
        });
$(document).on('click','#edit',function(){
  var id=$(this).data("id1");
   var matapelajaran=$(this).data("id2");
    $.ajax({
      url:"/myrev/php/gurupengajar/request/get_nilaibyid.php",
      method:"POST",
      data:{id:id, matapelajaran:matapelajaran},
      dataType:"text",
      success:function(data){
      $("#body_output").html(data);
                     }
    });

});


    });

  </script>
