<?php

	$nama =$_POST['nama'];
	$c1 =$_POST['c1'];
	$c2 =$_POST['c2'];
	$c3 =$_POST['c3'];
	$c4 =$_POST['c4'];
	$c5 =$_POST['c5'];
	$c6 =$_POST['c6'];
	$c7 =$_POST['c7'];
	$c8 =$_POST['c8'];
	$c9 =$_POST['c9'];
	$c10 =$_POST['c10'];
	$c11 =$_POST['c11'];
	$c12 =$_POST['c12'];
	$c13 =$_POST['c13'];
	$c14 =$_POST['c14'];
	$tahunajar =$_POST['tahunajar'];
	$semester =$_POST['semester'];
	$kelas =$_POST['kelas'];


 $connect = mysqli_connect("localhost", "root", "", "tugasakhir");  



	$sql = "INSERT INTO tb_data_siswa (id, nama, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14, tahunajar, semester, kelas, username, atribut) VALUES (null, '$nama', '$c1', '$c2', '$c3', '$c4', '$c5', '$c6', '$c7', '$c8', '$c9', '$c10', '$c11', '$c12', '$c13', '$c14', '$tahunajar', '$semester', '$kelas', ' ', ' ')";
 	if(mysqli_query($connect, $sql))
 	{
      echo 'Data Tersimpan';
 	} else {
    echo "Error updating record: " . mysqli_error();
}
