 <?php
 $connect = mysqli_connect("localhost", "root", "", "tugasakhir");  
 $nis = $_POST["nis"];
 $nilai = $_POST["nilai"];
 $kolom = $_POST["kolom"];

	$sql = "UPDATE tb_data_siswa SET $kolom='".$nilai."' WHERE nis='".$nis."'";
 	if(mysqli_query($connect, $sql))
 	{
      echo 'Data Updated';
 	}




 ?>
