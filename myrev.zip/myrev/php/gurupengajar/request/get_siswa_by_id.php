<?php

  $connect = mysqli_connect("localhost","root","","tugasakhir");

   if (!$connect) {
    die("Connection Failed:" .mysqli_connect_error());

   }
   $id = $_POST['id'];
  $output = '';
 $sql = "SELECT * FROM tb_data_siswa WHERE  id='".$id."'";
 $result = mysqli_query($connect, $sql);
 if(mysqli_num_rows($result) > 0)
 {
      while($row = mysqli_fetch_array($result))
      { ?>

         <form>
        <div class="table-responsive">
         <table class="table">
        <tr>
          <td colspan="3"><h3>From Edit Siswa</h3></td>
        </tr>
         <tr>
          <td>id</td>
          <td>:</td>
          <td><input type="text" id="id" value="<?php echo $row["id"];?>" disabled></td>
         </tr>
          <tr>
          <td>Nama</td>
          <td>:</td>
          <td>  <input type="text" id="nama"  value="<?php echo $row["nama"];?>"></td>
         </tr>
          <tr>
          <td>Agama</td>
          <td>:</td>
          <td>  <input type="text" id="c1" maxlength="3" value="<?php echo $row["c1"];?>"></td>
         </tr>
         <tr>
          <td>Pkn</td>
          <td>:</td>
          <td>  <input type="text" id="c2" maxlength="3" value="<?php echo $row["c2"];?>"></td>
         </tr>
          <tr>
          <td>Bahasa Indonesia</td>
          <td>:</td>
          <td><input type="text" id="c3" maxlength="3" value="<?php echo $row["c3"];?>"></td>
         </tr>
          <tr>
          <td>Bahasa Inggris</td>
          <td>:</td>
          <td><input type="text" id="c4" maxlength="3" value="<?php echo $row["c4"];?>"></td>
         </tr>
          <tr>
          <td>Matematika</td>
          <td>:</td>
          <td> <input type="text" id="c5" maxlength="3" value="<?php echo $row["c5"];?>"></td>
         </tr>
          <tr>
          <td>Fisika</td>
          <td>:</td>
          <td>  <input type="text" id="c6" maxlength="3" value="<?php echo $row["c6"];?>"></td>
         </tr>
         <tr>
          <td>Sejarah</td>
          <td>:</td>
          <td><input type="text" id="c7" maxlength="3" value="<?php echo $row["c7"];?>"></td>
         </tr>
          <tr>
          <td>Geografi</td>
          <td>:</td>
          <td> <input type="text" id="c8" maxlength="3" value="<?php echo $row["c8"];?>"></td>
         </tr>
          <tr>
          <td>Ekonomi</td>
          <td>:</td>
          <td> <input type="text" id="c9" maxlength="3" value="<?php echo $row["c9"];?>"></td>
         </tr>
         <tr>
          <td>Komputer</td>
          <td>:</td>
          <td> <input type="text" id="c10" maxlength="3" value="<?php echo $row["c10"];?>"></td>
         </tr>
         <tr>
          <td>Pramuka</td>
          <td>:</td>
          <td>

            <select id="c11" class="form-control">
              <?php echo "<option value=".$row["c11"]." class='alert alert-warning'>".$row["c11"]."</option>"?>
              <option value="A">A+</option>
              <option value="B+">B+</option>
              <option value="B">B</option>
              <option value="B-">B-</option>
              <option value="C+">C+</option>
              <option value="C">C</option>
              <option value="D">D</option>
            </select>

          </td>
         </tr>
          <tr>
          <td>Kedisiplinan</td>
          <td>:</td>
          <td>
             <select id="c12" class="form-control">
             <?php echo "<option value=".$row["c12"]." class='alert alert-warning'>".$row["c12"]."</option>"?>
              <option value="A+">A+</option>
              <option value="B+">B+</option>
              <option value="B">B</option>
              <option value="B-">B-</option>
              <option value="C+">C+</option>
              <option value="C">C</option>
              <option value="D">D</option>
            </select>
          </td>
          <tr>
          <td>Kebersihan</td>
          <td>:</td>
          <td>
              <select id="c13" class="form-control">
              <?php echo "<option value=".$row["c13"]." class='alert alert-warning'>".$row["c13"]."</option>"?>
              <option value="A+">A+</option>
              <option value="B+">B+</option>
              <option value="B">B</option>
              <option value="B-">B-</option>
              <option value="C+">C+</option>
              <option value="C">C</option>
              <option value="D">D</option>
            </select>
          </td>
         </tr>
         <tr>
          <td>Absensi</td>
          <td>:</td>
          <td><input type="number" id="c14" value="<?php echo $row["c14"];?>"></td>
         </tr>
          <tr>
          <td>Tahunajar</td>
          <td>:</td>
          <td>
              <select id="tahunajar" class="form-control">
              <?php echo "<option value=".$row["tahunajar"]." class='alert alert-warning'>".$row["tahunajar"]."</option>"?>
              <option value="2013/2014">2013/2014</option>
              <option value="2014/2015">2014/2015</option>
              <option value="2015/2016">2015/2016</option>
              <option value="2016/2017">2016/2017-</option>
              <option value="2017/2018">2017/2018</option>
              <option value="2018/2019">2018/2019</option>
              <option value="2019/2020">2019/2020</option>
            </select>
          </td>
         </tr>
          <tr>
          <td>Semester</td>
          <td>:</td>
          <td>

            <select id="semester" class="form-control">
            <?php echo "<option value=".$row["semester"]." class='alert alert-warning'>".$row["semester"]."</option>"?>
              <option value="1">1</option>
              <option value="2">2</option>
            </select>

          </td>
         </tr>
          <tr>
          <td>Kelas</td>
          <td>:</td>
          <td>
             <select id="kelas" class="form-control">
             <?php echo "<option value=".$row["kelas"]." class='alert alert-warning'>".$row["kelas"]."</option>"?>
              <option value="10">10</option>
              <option value="11">11</option>
              <option value="12">12</option>
            </select>
          </td>
         </tr>
          <tr>
          <td colspan="3"><button type="button" id="update">Update</button>
           <button type="button" id="cancel">Cancel</button></td>

         </tr>


         </table>
         </div>
         </form>
                  <div id="out"></div>
  <?php } }?>


  <script type="text/javascript">
    $(document).ready(function(){

      function refresh(){

    $.ajax({
        url: '/myrev/php/gurupengajar/pengaturan_siswa.php',
        method: 'POST',
        dataType:'text',
        success: function(data){
          if (data) {
           $("#body_output").html(data);
            $("#body_output").effect("shake");
          } else{
            alert("No Data Has Been Found !");

          };
        }
      });
  }
  function update(){
        var id = $("#id").val();
        var nama = $("#nama").val();
        var c1 = $("#c1").val();
        var c2 = $("#c2").val();
        var c3 = $("#c3").val();
        var c4 = $("#c4").val();
        var c5 = $("#c5").val();
        var c6 = $("#c6").val();
        var c7 = $("#c7").val();
        var c8 = $("#c8").val();
        var c9 = $("#c9").val();
        var c10 = $("#c10").val();
        var c11 = $("#c11").val();
        var c12 = $("#c12").val();
        var c13 = $("#c13").val();
        var c14 = $("#c14").val();
        var tahunajar = $("#tahunajar").val();
        var semester = $("#semester").val();
        var kelas = $("#kelas").val();

         $.ajax({
                url:"/myrev/php/gurupengajar/request/edit_siswa.php",
                method:"POST",
                data:{id:id, nama:nama, c1:c1, c2:c2, c3:c3, c4:c4, c5:c5, c6:c6, c7:c7, c8:c8, c9:c9, c10:c10, c11:c11,c12:c12, c13:c13, c14:c14, tahunajar:tahunajar, semester:semester, kelas:kelas},
                dataType:"text",
                success:function(data){
                    alert(data);
                    refresh();


                }
           });
  }

        $("#cancel").click(function(){
          refresh();
        });


        $("#update").click(function(){
          update();
        });

    });

  </script>
