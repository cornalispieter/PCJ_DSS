<?php
	$id =$_POST['id'];
	$nama =$_POST['nama'];
	$c1 =$_POST['c1'];
	$c2 =$_POST['c2'];
	$c3 =$_POST['c3'];
	$c4 =$_POST['c4'];
	$c5 =$_POST['c5'];
	$c6 =$_POST['c6'];
	$c7 =$_POST['c7'];
	$c8 =$_POST['c8'];
	$c9 =$_POST['c9'];
	$c10 =$_POST['c10'];
	$c11 =$_POST['c11'];
	$c12 =$_POST['c12'];
	$c13 =$_POST['c13'];
	$c14 =$_POST['c14'];
	$tahunajar =$_POST['tahunajar'];
	$semester =$_POST['semester'];
	$kelas =$_POST['kelas'];



 $connect = mysqli_connect("localhost", "root", "", "tugasakhir");  



	$sql = "UPDATE tb_data_siswa SET nama='$nama', c1='$c1',
      			c2='$c2',c3='$c3',c4='$c4',c5='$c5',c6='$c6',c7='$c7',c8='$c8',c9='$c9',c10='$c10',c11='$c11',c12='$c12',c13='$c13',c14='$c14',tahunajar='$tahunajar',semester='$semester', kelas='$kelas' "." WHERE id='$id'";
 	if(mysqli_query($connect, $sql))
 	{
      echo 'Data Updated';
 	} else {
    echo "Error updating record: " . mysqli_error();
}
