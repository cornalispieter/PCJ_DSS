 <form>
        <div class="table-responsive">
         <table class="table">
        <tr>
          <td colspan="3"><h3>Form Tambah Data Siswa</h3></td>
        </tr>
         <tr>
          <td>id</td>
          <td>:</td>
          <td><input type="hidden" id="id"  disabled></td>
         </tr>
          <tr>
          <td>Nama</td>
          <td>:</td>
          <td>  <input type="text" id="nama" ></td>
         </tr>
          <tr>
          <td>Agama</td>
          <td>:</td>
          <td>  <input type="text" id="c1" maxlength="3" ></td>
         </tr>
         <tr>
          <td>Pkn</td>
          <td>:</td>
          <td>  <input type="text" id="c2" maxlength="3"></td>
         </tr>
          <tr>
          <td>Bahasa Indonesia</td>
          <td>:</td>
          <td><input type="text" id="c3" maxlength="3"></td>
         </tr>
          <tr>
          <td>Bahasa Inggris</td>
          <td>:</td>
          <td><input type="text" id="c4" maxlength="3" "></td>
         </tr>
          <tr>
          <td>Matematika</td>
          <td>:</td>
          <td> <input type="text" id="c5" maxlength="3" ></td>
         </tr>
          <tr>
          <td>Fisika</td>
          <td>:</td>
          <td>  <input type="text" id="c6" maxlength="3"></td>
         </tr>
         <tr>
          <td>Sejarah</td>
          <td>:</td>
          <td><input type="text" id="c7" maxlength="3" ></td>
         </tr>
          <tr>
          <td>Geografi</td>
          <td>:</td>
          <td> <input type="text" id="c8" maxlength="3" ></td>
         </tr>
          <tr>
          <td>Ekonomi</td>
          <td>:</td>
          <td> <input type="text" id="c9" maxlength="3" ></td>
         </tr>
         <tr>
          <td>Komputer</td>
          <td>:</td>
          <td> <input type="text" id="c10" maxlength="3" ></td>
         </tr>
         <tr>
          <td>Pramuka</td>
          <td>:</td>
          <td> 

            <select id="c11" class="form-control">
             
              <option value="A">A</option>
              <option value="B+">B+</option>
              <option value="B">B</option>
              <option value="B-">B-</option>
              <option value="C+">C+</option>
              <option value="C">C</option>
              <option value="D">D</option>
            </select> 

          </td>
         </tr>
          <tr>
          <td>Kedisiplinan</td>
          <td>:</td>
          <td>
             <select id="c12" class="form-control">
             
              <option value="A">A</option>
              <option value="B+">B+</option>
              <option value="B">B</option>
              <option value="B-">B-</option>
              <option value="C+">C+</option>
              <option value="C">C</option>
              <option value="D">D</option>
            </select> 
          </td>
          <tr>
          <td>Kebersihan</td>
          <td>:</td>
          <td>
              <select id="c13" class="form-control">
              
              <option value="A">A</option>
              <option value="B+">B+</option>
              <option value="B">B</option>
              <option value="B-">B-</option>
              <option value="C+">C+</option>
              <option value="C">C</option>
              <option value="D">D</option>
            </select>
          </td>
         </tr>
         <tr>
          <td>Absensi</td>
          <td>:</td>
          <td><input type="number" id="c14" ></td>
         </tr>
          <tr>
          <td>Tahunajar</td>
          <td>:</td>
          <td>
              <select id="tahunajar" class="form-control">
              
              <option value="2013/2014">2013/2014</option>
              <option value="2014/2015">2014/2015</option>
              <option value="2015/2016">2015/2016</option>
              <option value="2016/2017">2016/2017</option>
              <option value="2017/2018">2017/2018</option>
              <option value="2018/2019">2018/2019</option>
              <option value="2019/2020">2019/2020</option>
            </select>
          </td>
         </tr>
          <tr>
          <td>Semester</td>
          <td>:</td>
          <td>
            
            <select id="semester" class="form-control">
             <option value="1">1</option>
              <option value="2">2</option>
            </select>

          </td>
         </tr>
          <tr>
          <td>Kelas</td>
          <td>:</td>
          <td>
             <select id="kelas" class="form-control">
             <option value="10">10</option>
              <option value="11">11</option>
              <option value="12">12</option>
            </select>
          </td>
         </tr>
          <tr>
          <td colspan="3"><button type="button" id="simpan">Simpan</button>
           <button type="button" id="cancel">Batal</button></td>
       
         </tr>
           
           
         </table>
         </div>
         </form>
  <script type="text/javascript">
    $(document).ready(function(){

        function refresh(){

           $.ajax({
        url: '/myrev/php/gurupengajar/pengaturan_siswa.php',
        method: 'POST',
        dataType:'text',
        success: function(data){
          if (data) {
           $("#body_output").html(data);
            $("#body_output").effect("shake");
          } else{
            alert("No Data Has Been Found !");

              };
            }
          });
         }

$("#cancel").click(function(){
          refresh();
        });

function simpan(){
  var nama = $("#nama").val();
        var c1 = $("#c1").val();
        var c2 = $("#c2").val();
        var c3 = $("#c3").val();
        var c4 = $("#c4").val();
        var c5 = $("#c5").val();
        var c6 = $("#c6").val();
        var c7 = $("#c7").val();
        var c8 = $("#c8").val();
        var c9 = $("#c9").val();
        var c10 = $("#c10").val();
        var c11 = $("#c11").val();
        var c12 = $("#c12").val();
        var c13 = $("#c13").val();
        var c14 = $("#c14").val();
        var tahunajar = $("#tahunajar").val();
        var semester = $("#semester").val();
        var kelas = $("#kelas").val();

        $.ajax({  
                url:"/myrev/php/gurupengajar/request/simpan_siswa.php",  
                method:"POST",  
                data:{ nama:nama, c1:c1, c2:c2, c3:c3, c4:c4, c5:c5, c6:c6, c7:c7, c8:c8, c9:c9, c10:c10, c11:c11,c12:c12, c13:c13, c14:c14, tahunajar:tahunajar, semester:semester, kelas:kelas},  
                dataType:"text",  
                success:function(data){  
                    alert(data);
                    refresh();

                    
                }  
           });  
}

$("#simpan").click(function(){
  simpan();
});

    });

      



  </script>