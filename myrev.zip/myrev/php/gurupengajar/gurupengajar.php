<?php
session_start();
if (!isset($_SESSION["username"])) {
	header("location:http://localhost/myrev/index.php");
}
	

?>
 

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Sistem Pendukung Keputusan</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $_SESSION["username"];?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        
                        <li class="divider"></li>
                        <li>
                            <a href="http://localhost/myrev/php/logout/logout.php"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                       <a href="#" id="dashboard"> <i class="glyphicon glyphicon-th-large"></i> Dashboard</a>
                    </li>
                    <li>
                      <a href="#" id="pengaturan-siswa">  <i class="glyphicon glyphicon-user"></i> Pengaturan Siswa </a>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                        <p><img src="/myrev/media/logo/smaimmanuel.jpg" width="40" height="50"> SMA IMMANUEL BATU</p>
                                
                            
                           <h3>Bagian Guru Pengajar</h3> 
                           
                        </h1>
                    </div>
                </div>
                <!-- /.row -->

                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="panel panel-default">
                            <div class="panel-body" align="justify" id="body_output">
                              

				            </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->

                
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>

    <script type="text/javascript">
        $(document).ready(function(){
          function refresh(){
        $.ajax({
        url: '/myrev/php/gurupengajar/request/get_pesan.php',
        method: 'POST',
        dataType:'text',
        success: function(data){
          if (data) {
           $("#body_output").html(data);
          } else{
            alert("No Data Has Been Found !");

          };
        }
      });
    }

    function pengaturan_siswa(){

    $.ajax({
        url: '/myrev/php/gurupengajar/pengaturan_siswa.php',
        method: 'POST',
        dataType:'text',
        success: function(data){
          if (data) {
           $("#body_output").html(data);
            $("#body_output").effect("shake");
          } else{
            alert("No Data Has Been Found !");

          };
        }
      });
  }

    refresh();
    $("#dashboard").click(function(){
        refresh();
    });

    $("#pengaturan-siswa").click(function(){
        pengaturan_siswa();
    });
        });
    </script>