<!DOCTYPE html>
<?php 
session_start();
if (isset($_SESSION["username"])) {
	if ($_SESSION["job_desk"] == 1) {
        header("location:http://localhost/myrev/php/kurikulum/kurikulum.php");
      }
      if ($_SESSION["job_desk"] == 2) {
        header("location:http://localhost/myrev/php/guruwali/guruwali.php");
      }
       if ($_SESSION["job_desk"] == 3) {
        header("location:http://localhost//myrev/php/gurupengajar/gurupengajar.php");
      }
}
?>
<head>
	<title>Sistem Pendukung Keputusan</title>
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="http://localhost/myrev/template/sb-admin/css/sb-admin.css" rel="stylesheet">
   
  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.0.2/css/responsive.bootstrap.min.css">
  <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://www.datatables.net/rss.xml">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css">
  <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/themes/smoothness/jquery-ui.min.css" />
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js">
  </script>
 <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js">
  </script>
  <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>

  </head>

<body>
 
  
  <link rel="stylesheet" type="text/css" href="http://localhost/myrev/css/login/login.css">
	<div class="login-page">
    <div class="form" id="formlogin">
      <form class="login-form">
      	<h3>Sistem Pendukung Keputusan <br/><small>Di SMA Immanuel Batu</small></h3>
         <img src="/myrev/media/logo/smaimmanuel.jpg" alt="Smiley face" height="150" width="125"> 
        <input type="text" placeholder="username" id="username" />
        <input type="password" placeholder="password" id="password" />
        <button type="button" id="login">login <span class="glyphicon glyphicon-ok"></span></button>
        <div id="error">
        </div>
      </form>
  </div>
</div>

<script type="text/javascript" src="/myrev/js/login/login.js"></script>


</body>
</html>