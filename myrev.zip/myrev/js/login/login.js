$(document).ready(function(){
	$("#login").click(function() {
	/* Act on the event */
		$("#error").show();
		var uname = $("#username").val();
		var passw = $("#password").val();

		if ($.trim(uname).length > 0 && $.trim(passw).length > 0) {
			$.ajax({
				url: '/myrev/php/login/login_prosess.php',
				method: 'POST',
				data: 'uname='+uname+"&passw="+passw,
				beforeSend : function(){
					$("#login").html("Connecting !!");
				},
				success: function(data){
					if (data) {
						var jobj= JSON.parse(data);
						var job_desk = jobj["job_desk"];
								if (job_desk == 1) {
									$("body").load("/myrev/php/kurikulum/kurikulum.php");	
								} else if ( job_desk == 2){
									$("body").load("/myrev/php/guruwali/guruwali.php");	
								} else if( job_desk == 3){
									$("body").load("/myrev/php/gurupengajar/gurupengajar.php");	
								};
					} else{
						$("#login").html("Login");
						$("#error").html("<span class='text-danger'>Username Atau Password Salah !</span>").fadeOut(1500);
						$("#formlogin").effect("shake");

					};
				}
			});
			
		} else{
			return false;
		};
	});

});