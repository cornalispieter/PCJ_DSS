$(document).ready(function(){
    

function get_data_siswa(){
     var tahunajar = $("#tahunajar").val();
     var semester = $("#semester").val();
      var kelas = $("#kelas").val();
     $.ajax({  
                url:"/myrev/php/guruwali/get_data_siswa.php",  
                method:"POST",  
                data:{ semester:semester, tahunajar:tahunajar, kelas:kelas},  
                dataType:"text",  
                success:function(data){  
                     $("#body_output").html(data);  
                }  
           });
}
$("#btn-pilih-data").click(function(){
    get_data_siswa();
});
});