$(document).ready(function(){

function get_pesan_server(){

    $.ajax({
        url: '/myrev/php/guruwali/get_pesan_server.php',
        method: 'POST',
        dataType:'text',
        success: function(data){
          if (data) {
           $("#body_output").html(data);
          } else{
            alert("No Data Has Been Found !");

          };
        }
      });
  }
 function get_menu_perangkingan(){
 	$.ajax({
        url: '/myrev/php/guruwali/get_menu_perangkingan.php',
        method: 'POST',
        dataType:'text',
        success: function(data){
          if (data) {
           $("#body_output").html(data);
          } else{
            alert("No Data Has Been Found !");

          };
        }
      });
 }




	get_pesan_server();

$("#dashboard").click(function(){
	get_pesan_server();
});
$("#perangkingan").click(function(){
	get_menu_perangkingan();
});



});