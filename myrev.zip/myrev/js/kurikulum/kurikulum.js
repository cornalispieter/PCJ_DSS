$(document).ready(function(){
	function refresh(){
		$.ajax({
        url: '/myrev/php/kurikulum/request/get_pesan.php',
        method: 'POST',
        dataType:'text',
        success: function(data){
          if (data) {
           $("#body_output").html(data);
          } else{
            alert("No Data Has Been Found !");

          };
        }
      });
	}
	function get_pengaturan_user(){

    $.ajax({
        url: '/myrev/php/kurikulum/pengaturan_user.php',
        method: 'POST',
        dataType:'text',
        success: function(data){
          if (data) {
           $("#body_output").html(data);
   			$("#body_output").effect("shake");
          } else{
            alert("No Data Has Been Found !");

          };
        }
      });
  }
  function show_add_user(){

    $.ajax({
        url: '/myrev/php/kurikulum/request/add_user.php',
        method: 'POST',
        dataType:'text',
        success: function(data){
          if (data) {
           $("#body_output").html(data);
          } else{
            alert("No Data Has Been Found !");

          };
        }
      });
  }
  function get_pengaturan_bobot(){

    $.ajax({
        url: '/myrev/php/kurikulum/pengaturan_bobot.php',
        method: 'POST',
        dataType:'text',
        success: function(data){
          if (data) {
           $("#body_output").html(data);
           $("#body_output").effect("shake");
          } else{
            alert("No Data Has Been Found !");

          };
        }
      });
  }
     refresh();

	$("#dashboard").click(function(){

		refresh();
	});
	$("#pengaturan-user").click(function(){
		get_pengaturan_user();
	});
	$("#pengaturan-bobot").click(function(){
		get_pengaturan_bobot();
	});
  $("#pengaturan-guru-wali").click(function(){
    get_pengaturan_guru_wali();
  });
  function get_pengaturan_guru_wali(){

    $.ajax({
        url: '/myrev/php/kurikulum/pengaturan_guruwali.php',
        method: 'POST',
        dataType:'text',
        success: function(data){
          if (data) {
           $("#body_output").html(data);
           $("#body_output").effect("shake");
          } else{
            alert("No Data Has Been Found !");

          };
        }
      });
  }
});