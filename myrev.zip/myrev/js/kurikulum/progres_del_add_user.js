$(document).ready(function(){
	$(document).on('click', '#btn-del-user', function(){  
           var id = $(this).data("id3");

              $.ajax({  
                     url:"/myrev/php/kurikulum/request/delete_user.php",  
                     method:"POST",  
                     data:{id:id},  
                     dataType:"text",  
                     success:function(data){  
                          alert(data);  
                          refresh();  
                     }  
                });  
                
           
      });

  function show_add_user(){

    $.ajax({
        url: '/myrev/php/kurikulum/request/add_user.php',
        method: 'POST',
        dataType:'text',
        success: function(data){
          if (data) {
           $("#body_output").html(data);
          } else{
            alert("No Data Has Been Found !");

          };
        }
      });
  }
  function save_user(){
    var username = $("#username").val();
    var password = $("#password").val();
    var job_desk = $("#job_desk").val();

    if (username == "") {
      alert("Username Tidak Boleh Kosong");
    }
    if (password == "") {
      alert("password tidak boleh kosong");
    }
    if (job_desk == "") {
      alert("Job desk Tidak boleh kosong");
    }
    $.ajax({  
                url:"/myrev/php/kurikulum/request/add_user_prosess.php",  
                method:"POST",  
                data:{username:username, password:password, job_desk:job_desk},  
                dataType:"text",  
                success:function(data)  
                {  
                     alert(data);  
                     refresh();  
                }  
           }) 

  }
  $("#btn-save-user").click(function(){
    save_user();
  });
  $("#btn-add-user").click(function(){
      show_add_user();
  });

  $("#btn-cancel-add-user").click(function(){
    refresh();
  });

  function refresh(){
    $.ajax({
        url: '/myrev/php/kurikulum/pengaturan_user.php',
        method: 'POST',
        dataType:'text',
        success: function(data){
          if (data) {
           $("#body_output").html(data);
        $("#body_output").effect("shake");
          } else{
            alert("No Data Has Been Found !");

          };
        }
      });
  }
});