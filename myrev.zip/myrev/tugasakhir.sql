-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2017 at 02:28 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tugasakhir`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_bobot`
--

CREATE TABLE `tb_bobot` (
  `id` int(11) NOT NULL,
  `mapel` varchar(30) NOT NULL,
  `atribut` varchar(30) NOT NULL,
  `nilai` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_bobot`
--

INSERT INTO `tb_bobot` (`id`, `mapel`, `atribut`, `nilai`) VALUES
(1, 'Nilai Akademis', 'c1', 0.4),
(11, 'pramuka', 'c11', 0.12),
(12, 'kedisiplinan', 'c12', 0.13),
(13, 'kebersihan', 'c13', 0.12),
(14, 'absensi', 'c14', 0.23);

-- --------------------------------------------------------

--
-- Table structure for table `tb_data_siswa`
--

CREATE TABLE `tb_data_siswa` (
  `id` int(2) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `c1` int(2) DEFAULT NULL,
  `c2` int(2) DEFAULT NULL,
  `c3` int(2) DEFAULT NULL,
  `c4` int(2) DEFAULT NULL,
  `c5` int(2) DEFAULT NULL,
  `c6` int(2) DEFAULT NULL,
  `c7` int(2) DEFAULT NULL,
  `c8` int(2) DEFAULT NULL,
  `c9` int(2) DEFAULT NULL,
  `c10` int(2) DEFAULT NULL,
  `c11` varchar(2) DEFAULT NULL,
  `c12` varchar(2) DEFAULT NULL,
  `c13` varchar(2) DEFAULT NULL,
  `c14` int(2) DEFAULT NULL,
  `tahunajar` varchar(9) DEFAULT NULL,
  `semester` varchar(10) DEFAULT NULL,
  `kelas` varchar(10) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `nis` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tb_data_siswa`
--

INSERT INTO `tb_data_siswa` (`id`, `nama`, `c1`, `c2`, `c3`, `c4`, `c5`, `c6`, `c7`, `c8`, `c9`, `c10`, `c11`, `c12`, `c13`, `c14`, `tahunajar`, `semester`, `kelas`, `username`, `nis`) VALUES
(1, 'FEBRI SEMUEL TENDEAN', 84, 81, 84, 78, 71, 72, 87, 76, 78, 75, 'B', 'B', 'A', 1, '2013/2014', 'II', 'X', 'bagus', '2444'),
(2, 'FEIXTER ALEXANDER', 82, 88, 76, 73, 72, 65, 89, 75, 75, 75, 'C', 'B', 'B', 1, '2013/2014', 'II', 'X', 'bagus', '2445'),
(3, 'GERSON WETAPO', 84, 93, 75, 75, 69, 68, 75, 75, 75, 75, 'C', 'B', 'A', 0, '2013/2014', 'II', 'X', 'bagus', '2447'),
(4, 'GIAN EVANGGERLISTA NOKE', 92, 75, 92, 88, 85, 76, 90, 80, 81, 85, 'B', 'A', 'B', 0, '2013/2014', 'II', 'X', 'bagus', '2448'),
(5, 'GOMEL YIGIBALDM', 86, 80, 75, 75, 75, 75, 80, 75, 75, 75, 'C', 'A', 'B', 0, '2013/2014', 'II', 'X', 'bagus', '2449'),
(6, 'GRACE PIRNA SARI', 90, 80, 75, 75, 75, 77, 81, 81, 79, 75, 'C', 'B', 'B', 6, '2013/2014', 'II', 'X', 'bagus', '2450'),
(7, 'HIZKIA EDO FERDIANSYAH', 91, 82, 80, 75, 75, 69, 78, 75, 77, 75, 'C', 'B', 'B', 3, '2013/2014', 'II', 'X', 'bagus', '2451'),
(8, 'IREINE SYEDI HARIMU', 88, 75, 94, 82, 73, 75, 80, 75, 80, 75, 'B', 'A', 'B', 0, '2013/2014', 'II', 'X', 'bagus', '2452'),
(9, 'ISAK SAMUEL TAN DIMARA', 83, 82, 79, 75, 75, 73, 80, 75, 75, 75, 'C', 'B', 'B', 10, '2013/2014', 'II', 'X', 'bagus', '2453'),
(10, 'ISAK SAMUEL PAISEI', 87, 75, 75, 75, 75, 77, 85, 75, 75, 75, 'B', 'A', 'A', 1, '2013/2014', 'II', 'X', 'bagus', '2454'),
(11, 'IVENA WAROMI', 86, 75, 75, 75, 75, 78, 79, 75, 75, 75, 'B', 'B', 'B', 0, '2013/2014', 'II', 'X', 'bagus', '2455'),
(12, 'IVKA UKRAINI HALEAN', 86, 76, 83, 72, 73, 76, 77, 75, 75, 75, 'B', 'B', 'B', 1, '2013/2014', 'II', 'X', 'bagus', '2456'),
(13, 'JORDI AMAHORUW', 90, 76, 78, 75, 71, 75, 76, 82, 75, 75, 'B', 'B', 'B', 0, '2013/2014', 'II', 'X', 'bagus', '2457'),
(14, 'KARMEL MIRACLE BENAYA', 89, 75, 78, 88, 79, 78, 79, 79, 77, 75, 'B', 'B', 'B', 2, '2013/2014', 'II', 'X', 'bagus', '2458'),
(15, 'LUSI WINDARTI SECO', 93, 85, 82, 75, 75, 79, 82, 75, 76, 80, 'B', 'B', 'B', 0, '2013/2014', 'II', 'X', 'bagus', '2459'),
(16, 'NOVA NATALIA', 83, 80, 88, 78, 75, 79, 87, 77, 80, 75, 'B', 'A', 'B', 1, '2013/2014', 'II', 'X', 'bagus', '2460'),
(17, 'NOVIA HANA TAMPUBOLON', 95, 87, 91, 77, 76, 77, 94, 75, 81, 75, 'B', 'B', 'B', 0, '2013/2014', 'II', 'X', 'bagus', '2461'),
(18, 'NOVIA LADY LAURENSIA', 84, 89, 76, 75, 75, 76, 79, 75, 75, 78, 'B', 'B', 'B', 0, '2013/2014', 'II', 'X', 'bagus', '2462'),
(19, 'ONDILES ULANIMBO', 86, 75, 75, 70, 71, 78, 78, 75, 75, 75, 'C', 'B', 'B', 0, '2013/2014', 'II', 'X', 'bagus', '2463'),
(20, 'RAIMON DARE DASINAPA', 91, 75, 82, 75, 77, 70, 82, 75, 76, 75, 'C', 'B', 'B', 1, '2013/2014', 'II', 'X', 'bagus', '2466'),
(21, 'RAUDA UMAMIT', 89, 89, 88, 84, 75, 84, 91, 76, 79, 75, 'B', 'A', 'A', 0, '2013/2014', 'II', 'X', 'bagus', '2467'),
(22, 'RIZKY ABDULRAHMAN', 82, 82, 75, 75, 75, 75, 77, 75, 76, 75, 'B+', 'B', 'B', 3, '2013/2014', 'II', 'X', 'bagus', '2468'),
(23, 'SONNY PRASETYA', 82, 75, 82, 75, 75, 75, 79, 75, 76, 75, 'B', 'B', 'B', 0, '2013/2014', 'II', 'X', 'bagus', '2471'),
(24, 'TANTO DAUD IMANUEL', 97, 95, 92, 98, 94, 82, 94, 90, 87, 90, 'B', 'A', 'A', 0, '2013/2014', 'II', 'X', 'bagus', '2472'),
(25, 'VIOLA CHRISTINAWATI', 83, 78, 75, 75, 77, 75, 82, 75, 83, 75, 'B', 'A', 'B', 0, '2013/2014', 'II', 'X', 'bagus', '2473'),
(26, 'WAHYU SATRIA WIBOWO', 88, 90, 91, 84, 78, 77, 91, 78, 80, 75, 'A', 'B', 'B', 0, '2013/2014', 'II', 'X', 'bagus', '2475'),
(27, 'WENDIRON WENDA', 83, 75, 75, 69, 75, 75, 80, 75, 75, 75, 'B', 'B', 'B', 0, '2013/2014', 'II', 'X', 'bagus', '2476'),
(28, 'WILLIHAM PAWIKA', 87, 80, 75, 75, 75, 75, 84, 76, 75, 75, 'C', 'B', 'B', 5, '2013/2014', 'II', 'X', 'bagus', '2477'),
(29, 'YABHEZ EGA HERLAMBANG', 86, 84, 84, 75, 75, 77, 80, 75, 78, 75, 'C', 'B', 'B', 0, '2013/2014', 'II', 'X', 'bagus', '2478'),
(30, 'YEREMIA D KABAK', 87, 75, 75, 70, 70, 64, 75, 75, 75, 75, 'B', 'B', 'B', 1, '2013/2014', 'II', 'X', 'bagus', '2479'),
(31, 'YOSEPH DWI KRISNANDA', 87, 79, 80, 80, 75, 73, 80, 75, 79, 80, 'B', 'B', 'B', 0, '2013/2014', 'II', 'X', 'bagus', '2480'),
(32, 'YUDHA ADHITYA KURNIAWAN', 94, 82, 77, 75, 75, 76, 81, 75, 77, 75, 'B+', 'B', 'B', 4, '2013/2014', 'II', 'X', 'bagus', '2481'),
(35, 'Pieter Cornalis Johannes', 75, 85, NULL, NULL, 70, NULL, NULL, NULL, NULL, NULL, NULL, 'B', 'B', NULL, '2012/2013', 'I', 'XI-IPA', 'bagus', '1375'),
(36, 'ANASTHASYA MARIA REGINA', 94, 81, 80, 77, 82, 80, 89, 79, 82, 82, 'A', 'B+', 'B+', 1, '2014/2015', 'I', 'X', 'bagus', '4252'),
(37, 'ANDRE CHRISTIAN SEMBIRING', 80, 84, 85, 84, 89, 80, 80, 81, 80, 86, 'A', 'C+', 'C+', 0, '2014/2015', 'I', 'X', 'bagus', '4253'),
(38, 'ANGELIA', 84, 77, 85, 83, 77, 80, 83, 85, 88, 90, 'A', 'A', 'B', 0, '2014/2015', 'I', 'X', 'bagus', '4361'),
(39, 'ANGGI HERDIANTI BERTUS', 76, 82, 83, 84, 87, 79, 85, 85, 89, 84, 'B+', 'C+', 'A', 0, '2014/2015', 'I', 'X', 'bagus', '4219'),
(40, 'CLEARY DANIEL ELNARE', 96, 76, 79, 83, 80, 82, 88, 87, 87, 80, 'A', 'B', 'A', 1, '2014/2015', 'I', 'X', 'bagus', '4331'),
(41, 'DEACY PRISTIO BUDI SULISTYANTI', 75, 72, 81, 81, 77, 79, 83, 86, 82, 77, 'B+', 'B', 'B+', 1, '2014/2015', 'I', 'X', 'bagus', '4293'),
(42, 'DENNIS KUMARA PRASETYO', 75, 78, 82, 84, 78, 88, 89, 84, 79, 79, 'B+', 'A', 'B+', 1, '2014/2015', 'I', 'X', 'bagus', '4294'),
(43, 'DONY EKA KUSUMA WARDANI', 76, 70, 84, 88, 79, 86, 85, 85, 77, 89, 'C+', 'B', 'B', 1, '2014/2015', 'I', 'X', 'bagus', '4264'),
(44, 'ELISABETH BIBI', 98, 81, 78, 87, 82, 81, 80, 86, 89, 81, 'B+', 'A', 'B+', 1, '2014/2015', 'I', 'X', 'bagus', '4296'),
(45, 'ELMIRA AYU DWI CRISTANTI', 75, 82, 82, 77, 86, 87, 80, 83, 84, 79, 'B', 'B', 'C+', 0, '2014/2015', 'I', 'X', 'bagus', '4366'),
(46, 'ERRI ADI ANDOYO', 86, 83, 79, 82, 83, 77, 81, 83, 89, 78, 'A', 'B+', 'B', 1, '2014/2015', 'I', 'X', 'bagus', '4367'),
(47, 'EVITA PUTRI ELDIANA', 77, 80, 84, 79, 84, 88, 89, 88, 85, 86, 'A', 'A', 'B', 1, '2014/2015', 'I', 'X', 'bagus', '4368'),
(48, 'FERDINANDUS EKA PUTRA SANTOSA', 91, 79, 85, 78, 80, 85, 89, 86, 87, 89, 'B', 'B+', 'B+', 5, '2014/2015', 'I', 'X', 'bagus', '4369'),
(49, 'FRANCISCUS DANI PRIAMBODO', 82, 79, 85, 89, 77, 78, 82, 81, 83, 86, 'C+', 'C+', 'C+', 0, '2014/2015', 'I', 'X', 'bagus', '4269'),
(50, 'ICHA VIENANDA NATHANIA', 84, 82, 78, 79, 85, 79, 78, 77, 80, 78, 'B', 'C+', 'B+', 0, '2014/2015', 'I', 'X', 'bagus', '4232'),
(51, 'IMELDA SEQUEIRA ALVES', 86, 80, 79, 80, 87, 83, 79, 84, 83, 85, 'A', 'B', 'B', 0, '2014/2015', 'I', 'X', 'bagus', '4271'),
(52, 'KUSUMAWICITRA PURWANTO', 81, 89, 79, 80, 83, 84, 87, 86, 84, 84, 'A', 'A', 'A', 0, '2014/2015', 'I', 'X', 'bagus', '4342'),
(53, 'LEONARDO MARIO SUNU WICAKSONO', 95, 85, 82, 77, 82, 84, 82, 90, 77, 84, 'B+', 'C+', 'B+', 0, '2014/2015', 'I', 'X', 'bagus', '4373'),
(54, 'MARIA AZARIA', 83, 78, 84, 88, 90, 86, 79, 88, 82, 89, 'A', 'A', 'B', 1, '2014/2015', 'I', 'X', 'bagus', '4308'),
(55, 'MARIA KARTIKA', 83, 87, 81, 83, 80, 90, 89, 82, 80, 83, 'A', 'C+', 'A', 0, '2014/2015', 'I', 'X', 'bagus', '4375'),
(56, 'NEVINDA APRILA', 83, 70, 81, 85, 81, 88, 77, 88, 86, 89, 'B+', 'C+', 'C+', 0, '2014/2015', 'I', 'X', 'bagus', '4344'),
(57, 'NISA KRISTINA WATI', 96, 83, 83, 86, 83, 87, 84, 87, 80, 77, 'B', 'C+', 'B+', 1, '2014/2015', 'I', 'X', 'bagus', '4241'),
(58, 'NOVAN SETYABUDI', 75, 84, 85, 88, 79, 89, 89, 85, 89, 77, 'A', 'A', 'A', 0, '2014/2015', 'I', 'X', 'bagus', '4379'),
(59, 'PENINA ELVIRA LAOS', 78, 82, 82, 79, 85, 77, 84, 82, 83, 79, 'B', 'A', 'C+', 7, '2014/2015', 'I', 'X', 'bagus', '4381'),
(60, 'PUTRI MEIBAWATI', 89, 80, 80, 80, 80, 90, 80, 78, 90, 77, 'A', 'B+', 'B+', 1, '2014/2015', 'I', 'X', 'bagus', '4277'),
(61, 'REYNALDI PRASETYA ADHITAMA', 94, 75, 78, 90, 86, 90, 83, 80, 82, 89, 'A', 'B', 'C+', 0, '2014/2015', 'I', 'X', 'bagus', '4244'),
(62, 'SALLY OCTIVIA', 75, 69, 83, 77, 80, 86, 86, 82, 84, 87, 'B+', 'B', 'A', 0, '2014/2015', 'I', 'X', 'bagus', '4281'),
(63, 'SIMON RICHARTSON AWOM', 76, 83, 82, 77, 83, 85, 84, 77, 79, 78, 'A', 'B+', 'A', 1, '2014/2015', 'I', 'X', 'bagus', '4385'),
(64, 'Y.B. MAHESA HANGGARA', 97, 89, 80, 83, 77, 88, 79, 79, 78, 89, 'C+', 'B', 'B+', 0, '2014/2015', 'I', 'X', 'bagus', '4354'),
(65, 'YERRY DWI PUTRA', 94, 88, 83, 89, 90, 89, 78, 90, 88, 90, 'B+', 'A', 'A', 0, '2014/2015', 'I', 'X', 'bagus', '4282'),
(66, 'YOHANNA PUTRI LESTARI', 77, 84, 85, 87, 78, 88, 90, 79, 79, 80, 'B', 'C+', 'B+', 0, '2014/2015', 'I', 'X', 'bagus', '4251'),
(67, 'YUDHA OKTAVIANO', 76, 82, 82, 81, 88, 89, 78, 88, 81, 82, 'C+', 'B', 'B', 1, '2014/2015', 'I', 'X', 'bagus', '4356'),
(68, 'ALEXANDER AGUNG PRASETYA PUTRA', 77, 81, 80, 78, 89, 84, 86, 78, 83, 88, 'B', 'C+', 'B+', 4, '2014/2015', 'I', 'X', 'bagus', '4357'),
(69, 'FEBRI SEMUEL TENDEAN', 88, 92, 82, 93, 87, 74, 79, 86, 84, 83, 'C+', 'C+', 'B+', 0, '2013/2014', 'I', 'X', 'bagus', '2444'),
(70, 'FEIXTER ALEXANDER', 61, 76, 60, 80, 72, 93, 78, 85, 74, 74, 'C+', 'C+', 'C+', 0, '2013/2014', 'I', 'X', 'bagus', '2445'),
(71, 'GERSON WETAPO', 61, 63, 95, 80, 88, 62, 76, 65, 86, 73, 'C+', 'B+', 'C+', 0, '2013/2014', 'I', 'X', 'bagus', '2447'),
(72, 'GIAN EVANGGERLISTA NOKE', 68, 62, 60, 65, 93, 75, 95, 74, 94, 68, 'C+', 'A', 'C+', 1, '2013/2014', 'I', 'X', 'bagus', '2448'),
(73, 'GOMEL YIGIBALDM', 76, 65, 89, 76, 83, 94, 84, 81, 93, 69, 'C+', 'C+', 'B+', 0, '2013/2014', 'I', 'X', 'bagus', '2449'),
(74, 'GRACE PIRNA SARI', 66, 76, 86, 89, 81, 66, 69, 86, 67, 67, 'B+', 'B+', 'C+', 0, '2013/2014', 'I', 'X', 'bagus', '2450'),
(75, 'HIZKIA EDO FERDIANSYAH', 68, 80, 86, 77, 72, 69, 84, 78, 77, 91, 'B+', 'A', 'C+', 0, '2013/2014', 'I', 'X', 'bagus', '2451'),
(76, 'IREINE SYEDI HARIMU', 90, 79, 60, 91, 74, 63, 84, 76, 64, 69, 'C+', 'A', 'B+', 0, '2013/2014', 'I', 'X', 'bagus', '2452'),
(77, 'ISAK SAMUEL TAN DIMARA', 74, 93, 68, 63, 87, 87, 81, 72, 88, 80, 'C+', 'B+', 'B+', 0, '2013/2014', 'I', 'X', 'bagus', '2453'),
(78, 'ISAK SAMUEL PAISEI', 67, 90, 75, 81, 74, 73, 89, 64, 94, 93, 'B+', 'C+', 'C+', 0, '2013/2014', 'I', 'X', 'bagus', '2454'),
(79, 'IVENA WAROMI', 81, 64, 90, 86, 88, 70, 87, 77, 75, 94, 'C+', 'B', 'C+', 0, '2013/2014', 'I', 'X', 'bagus', '2455'),
(80, 'IVKA UKRAINI HALEAN', 84, 82, 90, 90, 88, 71, 63, 76, 85, 75, 'C+', 'A', 'B+', 5, '2013/2014', 'I', 'X', 'bagus', '2456'),
(81, 'JORDI AMAHORUW', 87, 67, 95, 78, 60, 74, 72, 90, 82, 86, 'C+', 'C+', 'C+', 0, '2013/2014', 'I', 'X', 'bagus', '2457'),
(82, 'KARMEL MIRACLE BENAYA', 81, 74, 80, 62, 67, 83, 74, 85, 70, 67, 'C+', 'A', 'C+', 10, '2013/2014', 'I', 'X', 'bagus', '2458'),
(83, 'LUSI WINDARTI SECO', 70, 67, 79, 89, 82, 70, 68, 68, 79, 87, 'C+', 'B+', 'B+', 0, '2013/2014', 'I', 'X', 'bagus', '2459'),
(84, 'NOVA NATALIA', 94, 77, 86, 92, 66, 61, 75, 91, 86, 93, 'C+', 'A', 'C+', 0, '2013/2014', 'I', 'X', 'bagus', '2460'),
(85, 'NOVIA HANA TAMPUBOLON', 79, 93, 73, 85, 72, 72, 61, 69, 95, 89, 'B+', 'C+', 'C+', 1, '2013/2014', 'I', 'X', 'bagus', '2461'),
(86, 'NOVIA LADY LAURENSIA', 63, 90, 74, 61, 77, 81, 64, 89, 79, 76, 'C+', 'B+', 'B+', 0, '2013/2014', 'I', 'X', 'bagus', '2462'),
(87, 'ONDILES ULANIMBO', 70, 65, 64, 72, 64, 60, 79, 89, 72, 62, 'B+', 'C+', 'C+', 0, '2013/2014', 'I', 'X', 'bagus', '2463'),
(88, 'RAIMON DARE DASINAPA', 90, 84, 69, 80, 80, 82, 67, 92, 66, 93, 'B+', 'C+', 'A', 0, '2013/2014', 'I', 'X', 'bagus', '2466'),
(89, 'RAUDA UMAMIT', 90, 76, 61, 64, 67, 91, 88, 89, 72, 90, 'A', 'A', 'C+', 0, '2013/2014', 'I', 'X', 'bagus', '2467'),
(90, 'RIZKY ABDULRAHMAN', 89, 88, 76, 62, 84, 64, 85, 69, 63, 70, 'B+', 'A', 'C+', 0, '2013/2014', 'I', 'X', 'bagus', '2468'),
(91, 'SONNY PRASETYA', 61, 66, 80, 83, 92, 60, 94, 88, 60, 69, 'C+', 'C+', 'A', 0, '2013/2014', 'I', 'X', 'bagus', '2471'),
(92, 'TANTO DAUD IMANUEL', 76, 76, 93, 95, 82, 76, 69, 95, 80, 95, 'C+', 'A', 'C+', 0, '2013/2014', 'I', 'X', 'bagus', '2472'),
(93, 'VIOLA CHRISTINAWATI', 73, 67, 75, 63, 77, 68, 69, 95, 61, 73, 'B+', 'C+', 'B+', 0, '2013/2014', 'I', 'X', 'bagus', '2473'),
(94, 'WAHYU SATRIA WIBOWO', 72, 61, 78, 68, 89, 70, 69, 85, 75, 65, 'C+', 'A', 'C+', 2, '2013/2014', 'I', 'X', 'bagus', '2475'),
(95, 'WENDIRON WENDA', 80, 84, 61, 86, 89, 61, 73, 92, 94, 91, 'C+', 'B+', 'C+', 0, '2013/2014', 'I', 'X', 'bagus', '2476'),
(96, 'WILLIHAM PAWIKA', 79, 82, 62, 83, 62, 86, 92, 65, 75, 87, 'C+', 'B+', 'B+', 3, '2013/2014', 'I', 'X', 'bagus', '2477'),
(97, 'YABHEZ EGA HERLAMBANG', 72, 85, 80, 85, 64, 67, 85, 68, 86, 71, 'B+', 'C+', 'B+', 0, '2013/2014', 'I', 'X', 'bagus', '2478'),
(98, 'YEREMIA D KABAK', 60, 82, 65, 65, 76, 69, 90, 81, 92, 91, 'A', 'C+', 'C+', 0, '2013/2014', 'I', 'X', 'bagus', '2479'),
(99, 'YOSEPH DWI KRISNANDA', 60, 73, 85, 80, 66, 74, 95, 88, 92, 81, 'C+', 'C+', 'C+', 0, '2013/2014', 'I', 'X', 'bagus', '2480'),
(100, 'YUDHA ADHITYA KURNIAWAN', 72, 65, 93, 67, 87, 79, 86, 82, 84, 86, 'C+', 'C+', 'A', 1, '2013/2014', 'I', 'X', 'bagus', '2481'),
(101, 'ANASTHASYA MARIA REGINA', 73, 98, 95, 98, 73, 84, 85, 70, 79, 82, 'B', 'B+', 'B', 0, '2014/2015', 'II', 'X', 'bagus', '4252'),
(102, 'ANDRE CHRISTIAN SEMBIRING', 86, 74, 72, 93, 73, 73, 71, 85, 79, 86, 'B', 'C+', 'A', 0, '2014/2015', 'II', 'X', 'bagus', '4253'),
(103, 'ANGELIA', 71, 93, 76, 72, 74, 83, 82, 65, 83, 90, 'A', 'A', 'A', 0, '2014/2015', 'II', 'X', 'bagus', '4361'),
(104, 'ANGGI HERDIANTI BERTUS', 90, 96, 88, 81, 97, 84, 62, 81, 67, 84, 'B', 'B', 'B+', 0, '2014/2015', 'II', 'X', 'bagus', '4219'),
(105, 'CLEARY DANIEL ELNARE', 81, 95, 73, 97, 87, 87, 83, 62, 64, 80, 'B+', 'A', 'C', 0, '2014/2015', 'II', 'X', 'bagus', '4331'),
(106, 'DEACY PRISTIO BUDI SULISTYANTI', 74, 81, 96, 95, 91, 63, 69, 82, 64, 77, 'B+', 'C+', 'C', 2, '2014/2015', 'II', 'X', 'bagus', '4293'),
(107, 'DENNIS KUMARA PRASETYO', 80, 85, 84, 81, 89, 88, 74, 70, 82, 79, 'B', 'B+', 'A', 1, '2014/2015', 'II', 'X', 'bagus', '4294'),
(108, 'DONY EKA KUSUMA WARDANI', 94, 89, 89, 95, 90, 79, 84, 79, 86, 89, 'A', 'B', 'C+', 1, '2014/2015', 'II', 'X', 'bagus', '4264'),
(109, 'ELISABETH BIBI', 89, 89, 90, 79, 78, 76, 73, 66, 71, 81, 'B', 'B', 'A', 0, '2014/2015', 'II', 'X', 'bagus', '4296'),
(110, 'ELMIRA AYU DWI CRISTANTI', 90, 73, 76, 89, 76, 66, 85, 61, 65, 79, 'B', 'C+', 'C', 0, '2014/2015', 'II', 'X', 'bagus', '4366'),
(111, 'ERRI ADI ANDOYO', 82, 93, 95, 82, 73, 88, 64, 76, 72, 78, 'A', 'A', 'B', 1, '2014/2015', 'II', 'X', 'bagus', '4367'),
(112, 'EVITA PUTRI ELDIANA', 79, 70, 98, 75, 82, 71, 86, 79, 87, 86, 'B', 'B+', 'C+', 1, '2014/2015', 'II', 'X', 'bagus', '4368'),
(113, 'FERDINANDUS EKA PUTRA SANTOSA', 90, 77, 76, 70, 97, 84, 81, 84, 73, 89, 'B+', 'B+', 'C', 1, '2014/2015', 'II', 'X', 'bagus', '4369'),
(114, 'FRANCISCUS DANI PRIAMBODO', 95, 88, 85, 95, 76, 71, 63, 68, 81, 86, 'A', 'B', 'C', 0, '2014/2015', 'II', 'X', 'bagus', '4269'),
(115, 'ICHA VIENANDA NATHANIA', 92, 91, 83, 86, 77, 60, 83, 71, 73, 78, 'B', 'B+', 'A', 0, '2014/2015', 'II', 'X', 'bagus', '4232'),
(116, 'IMELDA SEQUEIRA ALVES', 83, 84, 88, 91, 91, 80, 77, 74, 73, 85, 'B+', 'B', 'B+', 0, '2014/2015', 'II', 'X', 'bagus', '4271'),
(117, 'KUSUMAWICITRA PURWANTO', 83, 96, 83, 77, 75, 87, 63, 81, 84, 84, 'B+', 'B', 'A', 0, '2014/2015', 'II', 'X', 'bagus', '4342'),
(118, 'LEONARDO MARIO SUNU WICAKSONO', 98, 90, 97, 90, 92, 77, 74, 87, 61, 84, 'B', 'B+', 'C', 0, '2014/2015', 'II', 'X', 'bagus', '4373'),
(119, 'MARIA AZARIA', 81, 88, 81, 95, 85, 70, 77, 62, 63, 89, 'B+', 'C+', 'C+', 0, '2014/2015', 'II', 'X', 'bagus', '4308'),
(120, 'MARIA KARTIKA', 73, 89, 83, 95, 80, 62, 77, 62, 72, 83, 'A', 'B+', 'B', 0, '2014/2015', 'II', 'X', 'bagus', '4375'),
(121, 'NEVINDA APRILA', 88, 93, 89, 71, 81, 68, 70, 85, 74, 89, 'B+', 'C+', 'C', 0, '2014/2015', 'II', 'X', 'bagus', '4344'),
(122, 'NISA KRISTINA WATI', 89, 86, 84, 97, 91, 60, 84, 81, 69, 77, 'A', 'B', 'A', 0, '2014/2015', 'II', 'X', 'bagus', '4241'),
(123, 'NOVAN SETYABUDI', 74, 87, 72, 83, 75, 76, 84, 85, 62, 77, 'B', 'B', 'A', 8, '2014/2015', 'II', 'X', 'bagus', '4379'),
(124, 'PENINA ELVIRA LAOS', 77, 86, 83, 92, 81, 87, 74, 65, 70, 79, 'A', 'B', 'B+', 2, '2014/2015', 'II', 'X', 'bagus', '4381'),
(125, 'PUTRI MEIBAWATI', 87, 73, 94, 75, 77, 63, 75, 74, 67, 77, 'B+', 'B+', 'A', 0, '2014/2015', 'II', 'X', 'bagus', '4277'),
(126, 'REYNALDI PRASETYA ADHITAMA', 70, 94, 74, 89, 88, 70, 77, 66, 70, 89, 'B+', 'B', 'A', 0, '2014/2015', 'II', 'X', 'bagus', '4244'),
(127, 'SALLY OCTIVIA', 85, 72, 92, 77, 73, 69, 68, 64, 78, 87, 'B', 'C+', 'A', 0, '2014/2015', 'II', 'X', 'bagus', '4281'),
(128, 'SIMON RICHARTSON AWOM', 96, 86, 80, 72, 85, 87, 71, 73, 87, 78, 'B+', 'B', 'C+', 7, '2014/2015', 'II', 'X', 'bagus', '4385'),
(129, 'Y.B. MAHESA HANGGARA', 89, 97, 94, 97, 91, 70, 83, 79, 67, 89, 'B+', 'B', 'A', 0, '2014/2015', 'II', 'X', 'bagus', '4354'),
(130, 'YERRY DWI PUTRA', 87, 88, 70, 72, 82, 62, 78, 87, 73, 90, 'B', 'A', 'C', 0, '2014/2015', 'II', 'X', 'bagus', '4282'),
(131, 'YOHANNA PUTRI LESTARI', 74, 94, 78, 87, 77, 69, 62, 73, 86, 80, 'B', 'B', 'C+', 0, '2014/2015', 'II', 'X', 'bagus', '4251'),
(132, 'YUDHA OKTAVIANO', 95, 94, 97, 94, 97, 89, 65, 63, 62, 82, 'B+', 'B+', 'B+', 1, '2014/2015', 'II', 'X', 'bagus', '4356'),
(133, 'ALEXANDER AGUNG PRASETYA PUTRA', 74, 82, 71, 91, 82, 87, 77, 73, 77, 88, 'A', 'C+', 'B+', 0, '2014/2015', 'II', 'X', 'bagus', '4357');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pesan_server`
--

CREATE TABLE `tb_pesan_server` (
  `id` int(11) NOT NULL,
  `pesan` text NOT NULL,
  `role` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pesan_server`
--

INSERT INTO `tb_pesan_server` (`id`, `pesan`, `role`) VALUES
(1, 'Berikut ini adalah tugas dari bagian kurikulum\r\n<ul>\r\n<li>Mengatur User Dalam Program ini Mulai Dari Bagian Kurikulum, Guru Wali, Dan Guru Pengajar</li>\r\n<li>Mengatur Kriteria Bobot Penilaian Siswa</li>\r\n<li>Menentukan Guru Wali Untuk Setiap Siswa</li>\r\n</ul>', '1'),
(2, 'Halaman Ini adalah bagian Guru Wali yang bertanggung jawab untuk melakukan prosess perangkingan.', '2'),
(3, 'Bagian Guru Pengajar <br/>\r\n\r\nBertugas mengatur nilai siswa mulai dari input data, update data, hapus data', '3');

-- --------------------------------------------------------

--
-- Table structure for table `tb_sorting`
--

CREATE TABLE `tb_sorting` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `c1` double DEFAULT NULL,
  `c2` double DEFAULT NULL,
  `c3` double DEFAULT NULL,
  `c4` double DEFAULT NULL,
  `c5` double DEFAULT NULL,
  `c6` double DEFAULT NULL,
  `c7` double DEFAULT NULL,
  `c8` double DEFAULT NULL,
  `c9` double DEFAULT NULL,
  `c10` double DEFAULT NULL,
  `c11` double DEFAULT NULL,
  `c12` double DEFAULT NULL,
  `c13` double DEFAULT NULL,
  `c14` double DEFAULT NULL,
  `total` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `id_user` varchar(8) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(35) NOT NULL,
  `job_desk` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `id_user`, `username`, `password`, `job_desk`) VALUES
(12, 'GRW', 'guruwali', 'bf8cd26e6c6732b8df17a31b54800ed8', '2'),
(15, 'GRW', 'gurupengajar', '63a9f0ea7bb98050796b649e85481845', '2'),
(17, 'GRP', 'pieter', '05215268063cb2c3101e2edd46363c64', '3'),
(18, 'KUR', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1'),
(19, 'GRW', 'bagus', '17b38fc02fd7e92f3edeb6318e3066d8', '2'),
(20, 'KUR', 'root', '63a9f0ea7bb98050796b649e85481845', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_bobot`
--
ALTER TABLE `tb_bobot`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_data_siswa`
--
ALTER TABLE `tb_data_siswa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_pesan_server`
--
ALTER TABLE `tb_pesan_server`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_sorting`
--
ALTER TABLE `tb_sorting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_bobot`
--
ALTER TABLE `tb_bobot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `tb_data_siswa`
--
ALTER TABLE `tb_data_siswa`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134;
--
-- AUTO_INCREMENT for table `tb_pesan_server`
--
ALTER TABLE `tb_pesan_server`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tb_sorting`
--
ALTER TABLE `tb_sorting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
